;Program compiled by GCBASIC (2025.01.10 (Windows 32 bit) : Build 1450) for Microchip MPASM/MPLAB-X Assembler using FreeBASIC 1.09.0/2026-05-03 CRC247
;Need help? 
;  Please donate to help support the operational costs of the project.  Donate via https://gcbasic.com/donate/
;  
;  See the GCBASIC forums at http://sourceforge.net/projects/gcbasic/forums,
;  Check the documentation and Help at http://gcbasic.sourceforge.net/help/,
;or, email us:
;   evanvennn at users dot sourceforge dot net
;********************************************************************************
;   Installation Dir : C:\Users\rasyoung\Desktop\DIY Tech For Experiments\Nugget\Pursuing the Nugget\nugget_frequency_meter_source\artifacts\toolchain-src\GCBASIC
;   Source file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\010_softdac_pwm_brightness\010_softdac_pwm_brightness.gcb
;   Setting file     : 
;   Preserve mode    : 0
;   Assembler        : 
;   Programmer       : 
;   Output file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\010_softdac_pwm_brightness\010_softdac_pwm_brightness.asm
;   Float Capability : 
;********************************************************************************

;Set up the assembler options (Chip type, clock source, other bits and pieces)
 LIST p=16F18424, r=DEC
 TITLE       "C:\Users\rasyoung\Desktop\nugget-fwlib\examples\010_softdac_pwm_brightness\010_softdac_pwm_brightness.gcb"
 SUBTITLE    "05-24-2026 16:57:36"
#include <P16F18424.inc>
 __CONFIG _CONFIG1, _FCMEN_ON & _CLKOUTEN_OFF & _RSTOSC_HFINT32 & _FEXTOSC_OFF
 __CONFIG _CONFIG2, _MCLRE_ON
 __CONFIG _CONFIG3, _WDTE_OFF
 __CONFIG _CONFIG4, _LVP_ON & _WRTSAF_OFF & _WRTD_OFF & _WRTB_OFF
 __CONFIG _CONFIG5, _CP_OFF

;********************************************************************************

;Set aside memory locations for variables
;  Shared/Access RAM = (SA)
DELAYTEMP                        EQU     112          ; 0x70 (SA)
DELAYTEMP2                       EQU     113          ; 0x71 (SA)
LEVEL                            EQU      32          ; 0x20
RB_LEVEL                         EQU      33          ; 0x21
RB_OFFTIME                       EQU      34          ; 0x22
RB_ONTIME                        EQU      35          ; 0x23
SYSBYTETEMPX                     EQU     112          ; 0x70 (SA)
SYSDIVMULTA                      EQU     119          ; 0x77 (SA)
SYSDIVMULTA_H                    EQU     120          ; 0x78 (SA)
SYSFORLOOPSTEP0                  EQU      36          ; 0x24
SYSFORLOOPSTEP0_H                EQU      37          ; 0x25
SYSINTEGERTEMPA                  EQU     117          ; 0x75 (SA)
SYSINTEGERTEMPA_H                EQU     118          ; 0x76 (SA)
SYSINTEGERTEMPB                  EQU     121          ; 0x79 (SA)
SYSINTEGERTEMPB_H                EQU     122          ; 0x7A (SA)
SYSTEMP1                         EQU      38          ; 0x26
SYSTEMP2                         EQU      39          ; 0x27
SYSTEMP2_H                       EQU      40          ; 0x28
SYSTEMP3                         EQU      41          ; 0x29
SYSWAITTEMPMS                    EQU     114          ; 0x72 (SA)
SYSWAITTEMPMS_H                  EQU     115          ; 0x73 (SA)

;********************************************************************************

;Vectors
	ORG	0
	pagesel	BASPROGRAMSTART
	goto	BASPROGRAMSTART
	ORG	4
	retfie

;********************************************************************************

;Program_memory_page: 0
	ORG	5
BASPROGRAMSTART
;Call initialisation routines
	call	INITSYS

;Start_of_the_main_program
	call	RB_BOARD_INIT
	call	RB_LED_STATUS_INIT
SysDoLoop_S1
	clrf	LEVEL
SysForLoop1
;Init SysForLoopStep0 :#0
	movlw	10
	movwf	SysForLoopStep0
	clrf	SysForLoopStep0_H
	movf	LEVEL,W
	movwf	RB_LEVEL
	call	RB_SOFTDAC_PULSEWIDTH_RC0
	btfss	SYSFORLOOPSTEP0_H,7
	goto	ELSE1_1
	movlw	100
	subwf	LEVEL,W
	movwf	SysTemp1
	comf	SysForLoopStep0,W
	movwf	SysTemp2
	comf	SysForLoopStep0_H,W
	movwf	SysTemp2_H
	incf	SysTemp2,F
	btfsc	STATUS,Z
	incf	SysTemp2_H,F
	movf	SysTemp1,W
	movwf	SysINTEGERTempA
	clrf	SysINTEGERTempA_H
	movf	SysTemp2,W
	movwf	SysINTEGERTempB
	movf	SysTemp2_H,W
	movwf	SysINTEGERTempB_H
	call	SYSCOMPLESSTHANINT
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF2
	movf	SysForLoopStep0,W
	addwf	LEVEL,F
	goto	SysForLoop1
ENDIF2
	goto	ENDIF1
ELSE1_1
	movf	LEVEL,W
	sublw	100
	movwf	SysTemp1
	movwf	SysINTEGERTempA
	clrf	SysINTEGERTempA_H
	movf	SysForLoopStep0,W
	movwf	SysINTEGERTempB
	movf	SysForLoopStep0_H,W
	movwf	SysINTEGERTempB_H
	call	SYSCOMPLESSTHANINT
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF3
	movf	SysForLoopStep0,W
	addwf	LEVEL,F
	goto	SysForLoop1
ENDIF3
ENDIF1
SysForLoopEnd1
	goto	SysDoLoop_S1
SysDoLoop_E1
BASPROGRAMEND
	sleep
	goto	BASPROGRAMEND

;********************************************************************************

Delay_MS
	incf	SysWaitTempMS_H, F
DMS_START
	movlw	14
	movwf	DELAYTEMP2
DMS_OUTER
	movlw	189
	movwf	DELAYTEMP
DMS_INNER
	decfsz	DELAYTEMP, F
	goto	DMS_INNER
	decfsz	DELAYTEMP2, F
	goto	DMS_OUTER
	decfsz	SysWaitTempMS, F
	goto	DMS_START
	decfsz	SysWaitTempMS_H, F
	goto	DMS_START
	return

;********************************************************************************

INITSYS
;Default settings for microcontrollers with _OSCCON1_
	movlw	96
	banksel	OSCCON1
	movwf	OSCCON1
	clrf	OSCCON3
	clrf	OSCEN
	clrf	OSCTUNE
;The MCU is a chip family ChipFamily
;OSCCON type is 102
	movlw	6
	movwf	OSCFRQ
;_Complete_the_chip_setup_of_BSR_ADCs_ANSEL_and_other_key_setup_registers_or_register_bits
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	CM2CON0
	bcf	CM2CON0,C2EN
	bcf	CM1CON0,C1EN
	banksel	PORTA
	clrf	PORTA
	clrf	PORTC
	return

;********************************************************************************

RB_BOARD_INIT
	goto	RB_CORE_INIT

;********************************************************************************

RB_CORE_ALLDIGITAL
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	STATUS
	return

;********************************************************************************

RB_CORE_CLEARLATCHES
	clrf	LATA
	clrf	LATC
	return

;********************************************************************************

RB_CORE_INIT
	call	RB_CORE_ALLDIGITAL
	goto	RB_CORE_CLEARLATCHES

;********************************************************************************

RB_LED_STATUS_INIT
	bcf	TRISC,0
	banksel	ANSELC
	bcf	ANSELC,0
	banksel	LATC
	bcf	LATC,0
	return

;********************************************************************************

RB_SOFTDAC_PULSEWIDTH_RC0
	movf	RB_LEVEL,W
	movwf	RB_ONTIME
	movf	RB_LEVEL,W
	sublw	100
	movwf	RB_OFFTIME
	bsf	LATC,0
	movf	RB_ONTIME,W
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	bcf	LATC,0
	movf	RB_OFFTIME,W
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	goto	Delay_MS

;********************************************************************************

SYSCOMPLESSTHANINT
	clrf	SYSBYTETEMPX
	btfss	SYSINTEGERTEMPA_H,7
	goto	ELSE4_1
	btfsc	SYSINTEGERTEMPB_H,7
	goto	ENDIF5
	comf	SYSBYTETEMPX,F
	return
ENDIF5
	comf	SYSINTEGERTEMPA,W
	movwf	SYSDIVMULTA
	comf	SYSINTEGERTEMPA_H,W
	movwf	SYSDIVMULTA_H
	incf	SYSDIVMULTA,F
	btfsc	STATUS,Z
	incf	SYSDIVMULTA_H,F
	comf	SYSINTEGERTEMPB,W
	movwf	SYSINTEGERTEMPA
	comf	SYSINTEGERTEMPB_H,W
	movwf	SYSINTEGERTEMPA_H
	incf	SYSINTEGERTEMPA,F
	btfsc	STATUS,Z
	incf	SYSINTEGERTEMPA_H,F
	movf	SYSDIVMULTA,W
	movwf	SYSINTEGERTEMPB
	movf	SYSDIVMULTA_H,W
	movwf	SYSINTEGERTEMPB_H
	goto	ENDIF4
ELSE4_1
	btfsc	SYSINTEGERTEMPB_H,7
	return
ENDIF4
	movf	SYSINTEGERTEMPA_H,W
	subwf	SYSINTEGERTEMPB_H,W
	btfss	STATUS,C
	return
	movf	SYSINTEGERTEMPB_H,W
	subwf	SYSINTEGERTEMPA_H,W
	btfss	STATUS,C
	goto	SCLTINTTRUE
	movf	SYSINTEGERTEMPB,W
	subwf	SYSINTEGERTEMPA,W
	btfsc	STATUS,C
	return
SCLTINTTRUE
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

;Program_memory_page: 1
	ORG	2048

 END
