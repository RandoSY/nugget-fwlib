;Program compiled by GCBASIC (2025.01.10 (Windows 32 bit) : Build 1450) for Microchip MPASM/MPLAB-X Assembler using FreeBASIC 1.09.0/2026-05-03 CRC247
;Need help? 
;  Please donate to help support the operational costs of the project.  Donate via https://gcbasic.com/donate/
;  
;  See the GCBASIC forums at http://sourceforge.net/projects/gcbasic/forums,
;  Check the documentation and Help at http://gcbasic.sourceforge.net/help/,
;or, email us:
;   evanvennn at users dot sourceforge dot net
;********************************************************************************
;   Installation Dir : C:\Users\rasyoung\Desktop\DIY Tech For Experiments\Nugget\Pursuing the Nugget\nugget_frequency_meter_source\artifacts\toolchain-src\GCBASIC
;   Source file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\007_gsa_hello_status\007_gsa_hello_status.gcb
;   Setting file     : 
;   Preserve mode    : 0
;   Assembler        : 
;   Programmer       : 
;   Output file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\007_gsa_hello_status\007_gsa_hello_status.asm
;   Float Capability : 
;********************************************************************************

;Set up the assembler options (Chip type, clock source, other bits and pieces)
 LIST p=16F18424, r=DEC
 TITLE       "C:\Users\rasyoung\Desktop\nugget-fwlib\examples\007_gsa_hello_status\007_gsa_hello_status.gcb"
 SUBTITLE    "05-24-2026 16:57:22"
#include <P16F18424.inc>
 __CONFIG _CONFIG1, _FCMEN_ON & _CLKOUTEN_OFF & _RSTOSC_HFINT32 & _FEXTOSC_OFF
 __CONFIG _CONFIG2, _MCLRE_ON
 __CONFIG _CONFIG3, _WDTE_OFF
 __CONFIG _CONFIG4, _LVP_ON & _WRTSAF_OFF & _WRTD_OFF & _WRTB_OFF
 __CONFIG _CONFIG5, _CP_OFF

;********************************************************************************

;Set aside memory locations for variables
;  Shared/Access RAM = (SA)
COMPORT                          EQU      32          ; 0x20
DELAYTEMP                        EQU     112          ; 0x70 (SA)
DELAYTEMP2                       EQU     113          ; 0x71 (SA)
HSERPRINTCRLFCOUNT               EQU      33          ; 0x21
PRINTLEN                         EQU      34          ; 0x22
RB_LINE                          EQU    8614          ; 0x21A6
RB_LINECOUNT                     EQU      35          ; 0x23
RB_TEXT                          EQU    8603          ; 0x219B
RB_VALUE                         EQU      36          ; 0x24
RB_VALUE_E                       EQU      39          ; 0x27
RB_VALUE_H                       EQU      37          ; 0x25
RB_VALUE_U                       EQU      38          ; 0x26
SERDATA                          EQU      40          ; 0x28
SERPRINTVAL                      EQU      41          ; 0x29
SERPRINTVAL_E                    EQU      44          ; 0x2C
SERPRINTVAL_H                    EQU      42          ; 0x2A
SERPRINTVAL_U                    EQU      43          ; 0x2B
STRINGPOINTER                    EQU      45          ; 0x2D
SYSBITVAR1                       EQU      46          ; 0x2E
SYSBITVAR2                       EQU      47          ; 0x2F
SYSBYTETEMPA                     EQU     117          ; 0x75 (SA)
SYSBYTETEMPX                     EQU     112          ; 0x70 (SA)
SYSCALCTEMPA                     EQU     117          ; 0x75 (SA)
SYSCALCTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSCALCTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSCALCTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSDIVLOOP                       EQU     116          ; 0x74 (SA)
SYSLONGDIVMULTA                  EQU      48          ; 0x30
SYSLONGDIVMULTA_E                EQU      51          ; 0x33
SYSLONGDIVMULTA_H                EQU      49          ; 0x31
SYSLONGDIVMULTA_U                EQU      50          ; 0x32
SYSLONGDIVMULTB                  EQU      52          ; 0x34
SYSLONGDIVMULTB_E                EQU      55          ; 0x37
SYSLONGDIVMULTB_H                EQU      53          ; 0x35
SYSLONGDIVMULTB_U                EQU      54          ; 0x36
SYSLONGDIVMULTX                  EQU      56          ; 0x38
SYSLONGDIVMULTX_E                EQU      59          ; 0x3B
SYSLONGDIVMULTX_H                EQU      57          ; 0x39
SYSLONGDIVMULTX_U                EQU      58          ; 0x3A
SYSLONGTEMPA                     EQU     117          ; 0x75 (SA)
SYSLONGTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSLONGTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSLONGTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSLONGTEMPB                     EQU     121          ; 0x79 (SA)
SYSLONGTEMPB_E                   EQU     124          ; 0x7C (SA)
SYSLONGTEMPB_H                   EQU     122          ; 0x7A (SA)
SYSLONGTEMPB_U                   EQU     123          ; 0x7B (SA)
SYSLONGTEMPX                     EQU     112          ; 0x70 (SA)
SYSLONGTEMPX_E                   EQU     115          ; 0x73 (SA)
SYSLONGTEMPX_H                   EQU     113          ; 0x71 (SA)
SYSLONGTEMPX_U                   EQU     114          ; 0x72 (SA)
SYSPRINTBUFFER                   EQU    8592          ; 0x2190
SYSPRINTBUFFLEN                  EQU      60          ; 0x3C
SYSPRINTDATAHANDLER              EQU      61          ; 0x3D
SYSPRINTDATAHANDLER_H            EQU      62          ; 0x3E
SYSPRINTTEMP                     EQU      63          ; 0x3F
SYSRB_LABELHANDLER               EQU      64          ; 0x40
SYSRB_LABELHANDLER_H             EQU      65          ; 0x41
SYSRB_TEXTHANDLER                EQU      66          ; 0x42
SYSRB_TEXTHANDLER_H              EQU      67          ; 0x43
SYSREPEATTEMP1                   EQU      68          ; 0x44
SYSSTRINGA                       EQU     119          ; 0x77 (SA)
SYSSTRINGA_H                     EQU     120          ; 0x78 (SA)
SYSSTRINGLENGTH                  EQU     118          ; 0x76 (SA)
SYSTEMP1                         EQU      69          ; 0x45
SYSTEMP1_E                       EQU      72          ; 0x48
SYSTEMP1_H                       EQU      70          ; 0x46
SYSTEMP1_U                       EQU      71          ; 0x47
SYSTEMPARRAY                     EQU    8647          ; 0x21C7
SYSWAITTEMPMS                    EQU     114          ; 0x72 (SA)
SYSWAITTEMPMS_H                  EQU     115          ; 0x73 (SA)

;********************************************************************************

;Alias variables
AFSR0 EQU 4
AFSR0_H EQU 5

;********************************************************************************

;Vectors
	ORG	0
	pagesel	BASPROGRAMSTART
	goto	BASPROGRAMSTART
	ORG	4
	retfie

;********************************************************************************

;Program_memory_page: 0
	ORG	5
BASPROGRAMSTART
;Call initialisation routines
	call	INITSYS
	call	INITUSART

;Start_of_the_main_program
	call	RB_BOARD_INIT
	call	RB_LED_STATUS_INIT
	call	RB_GSA_INIT
	call	RB_GSA_SENDID
SysDoLoop_S1
	call	FN_RB_GSA_ISLINEREADY
	btfsc	SYSBITVAR2,0
	call	RB_GSA_PROCESSLINE
	call	RB_LED_STATUS_TOGGLE
	movlw	250
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	goto	SysDoLoop_S1
SysDoLoop_E1
BASPROGRAMEND
	sleep
	goto	BASPROGRAMEND

;********************************************************************************

Delay_MS
	incf	SysWaitTempMS_H, F
DMS_START
	movlw	14
	movwf	DELAYTEMP2
DMS_OUTER
	movlw	189
	movwf	DELAYTEMP
DMS_INNER
	decfsz	DELAYTEMP, F
	goto	DMS_INNER
	decfsz	DELAYTEMP2, F
	goto	DMS_OUTER
	decfsz	SysWaitTempMS, F
	goto	DMS_START
	decfsz	SysWaitTempMS_H, F
	goto	DMS_START
	return

;********************************************************************************

HSERPRINT430
	movf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movf	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	PRINTLEN
	movf	PRINTLEN,F
	btfsc	STATUS, Z
	goto	ENDIF8
	clrf	SYSPRINTTEMP
	movlw	1
	subwf	PRINTLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd1
SysForLoop1
	incf	SYSPRINTTEMP,F
	movf	SYSPRINTTEMP,W
	addwf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movlw	0
	addwfc	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	SERDATA
	call	HSERSEND418
	movf	PRINTLEN,W
	subwf	SYSPRINTTEMP,W
	btfss	STATUS, C
	goto	SysForLoop1
SysForLoopEnd1
ENDIF8
	return

;********************************************************************************

HSERPRINT435
	clrf	SYSPRINTBUFFLEN
SysDoLoop_S2
	incf	SYSPRINTBUFFLEN,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTBUFFLEN,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movf	SERPRINTVAL,W
	movwf	SysLONGTempA
	movf	SERPRINTVAL_H,W
	movwf	SysLONGTempA_H
	movf	SERPRINTVAL_U,W
	movwf	SysLONGTempA_U
	movf	SERPRINTVAL_E,W
	movwf	SysLONGTempA_E
	movlw	10
	movwf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSDIVSUB32
	movf	SysLONGTempX,W
	movwf	INDF0
	movf	SYSCALCTEMPA,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPA_H,W
	movwf	SERPRINTVAL_H
	movf	SYSCALCTEMPA_U,W
	movwf	SERPRINTVAL_U
	movf	SYSCALCTEMPA_E,W
	movwf	SERPRINTVAL_E
	movf	serprintval,W
	movwf	SysLONGTempA
	movf	serprintval_H,W
	movwf	SysLONGTempA_H
	movf	serprintval_U,W
	movwf	SysLONGTempA_U
	movf	serprintval_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	comf	SysByteTempX,F
	btfsc	SysByteTempX,0
	goto	SysDoLoop_S2
SysDoLoop_E2
	incf	SYSPRINTBUFFLEN,W
	movwf	SYSPRINTTEMP
	movlw	1
	subwf	SYSPRINTBUFFLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd2
SysForLoop2
	decf	SYSPRINTTEMP,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTTEMP,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movlw	48
	addwf	INDF0,W
	movwf	SERDATA
	call	HSERSEND418
	movf	SYSPRINTTEMP,W
	sublw	1
	btfss	STATUS, C
	goto	SysForLoop2
SysForLoopEnd2
	return

;********************************************************************************

HSERPRINTCRLF
	movf	HSERPRINTCRLFCOUNT,W
	movwf	SysRepeatTemp1
	btfsc	STATUS,Z
	goto	SysRepeatLoopEnd1
SysRepeatLoop1
	movlw	13
	movwf	SERDATA
	call	HSERSEND418
	movlw	10
	movwf	SERDATA
	call	HSERSEND418
	decfsz	SysRepeatTemp1,F
	goto	SysRepeatLoop1
SysRepeatLoopEnd1
	return

;********************************************************************************

HSERSEND418
HSERSENDUSART1HANDLER
	movf	SERDATA,W
	banksel	TXREG
	movwf	TXREG
	movlw	1
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	banksel	STATUS
	goto	Delay_MS

;********************************************************************************

INITSYS
;Default settings for microcontrollers with _OSCCON1_
	movlw	96
	banksel	OSCCON1
	movwf	OSCCON1
	clrf	OSCCON3
	clrf	OSCEN
	clrf	OSCTUNE
;The MCU is a chip family ChipFamily
;OSCCON type is 102
	movlw	6
	movwf	OSCFRQ
;_Complete_the_chip_setup_of_BSR_ADCs_ANSEL_and_other_key_setup_registers_or_register_bits
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	CM2CON0
	bcf	CM2CON0,C2EN
	bcf	CM1CON0,C1EN
	banksel	PORTA
	clrf	PORTA
	clrf	PORTC
	return

;********************************************************************************

INITUSART
	movlw	3
	banksel	SP1BRGH
	movwf	SP1BRGH
	movlw	64
	movwf	SP1BRGL
	movlw	64
	movwf	SPBRG
	bsf	BAUD1CON,BRG16
	bsf	TX1STA,BRGH
	bcf	TX1STA,SYNC_TX1STA
	bsf	TX1STA,TXEN
	bsf	RC1STA,SPEN
	bsf	RC1STA,CREN
	bsf	RC1STA,CREN
	banksel	STATUS
	return

;********************************************************************************

RB_BOARD_INIT
	goto	RB_CORE_INIT

;********************************************************************************

RB_CORE_ALLDIGITAL
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	STATUS
	return

;********************************************************************************

RB_CORE_CLEARLATCHES
	clrf	LATA
	clrf	LATC
	return

;********************************************************************************

RB_CORE_INIT
	call	RB_CORE_ALLDIGITAL
	goto	RB_CORE_CLEARLATCHES

;********************************************************************************

RB_GSA_INIT
	call	RB_LINEBUF_INIT
	bcf	SYSBITVAR1,6
	bcf	SYSBITVAR1,7
	return

;********************************************************************************

FN_RB_GSA_ISLINEREADY
	bcf	SYSBITVAR2,0
	btfsc	SYSBITVAR1,4
	bsf	SYSBITVAR2,0
	return

;********************************************************************************

RB_GSA_PROCESSLINE
	btfss	SYSBITVAR1,5
	goto	ENDIF5
	movlw	low StringTable37
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable37) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDERR
	call	RB_LINEBUF_CLEAR
	return
ENDIF5
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable38
	movwf	SysStringA
	movlw	(high StringTable38) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_1
	call	RB_GSA_SENDID
	goto	ENDIF6
ELSE6_1
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable39
	movwf	SysStringA
	movlw	(high StringTable39) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_2
	call	RB_GSA_SENDID
	goto	ENDIF6
ELSE6_2
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable40
	movwf	SysStringA
	movlw	(high StringTable40) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_3
	btfss	SYSBITVAR1,7
	goto	ELSE7_1
	movlw	low StringTable41
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable41) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF7
ELSE7_1
	movlw	low StringTable42
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable42) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
ENDIF7
	goto	ENDIF6
ELSE6_3
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable43
	movwf	SysStringA
	movlw	(high StringTable43) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_4
	bsf	SYSBITVAR1,7
	movlw	low StringTable43
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable43) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_4
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable44
	movwf	SysStringA
	movlw	(high StringTable44) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_5
	bcf	SYSBITVAR1,7
	movlw	low StringTable44
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable44) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_5
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable45
	movwf	SysStringA
	movlw	(high StringTable45) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_6
	bcf	SYSBITVAR1,7
	bcf	SYSBITVAR1,6
	movlw	low StringTable45
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable45) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_6
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable46
	movwf	SysStringA
	movlw	(high StringTable46) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_7
	movlw	low StringTable46
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable46) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_7
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable47
	movwf	SysStringA
	movlw	(high StringTable47) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_8
	movlw	low StringTable48
	movwf	SysRB_LABELHandler
	movlw	(high StringTable48) | 128
	movwf	SysRB_LABELHandler_H
	clrf	RB_VALUE
	clrf	RB_VALUE_H
	clrf	RB_VALUE_U
	clrf	RB_VALUE_E
	call	RB_GSA_SENDDATAINT
	goto	ENDIF6
ELSE6_8
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable49
	movwf	SysStringA
	movlw	(high StringTable49) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_9
	bsf	SYSBITVAR1,6
	movlw	low StringTable49
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable49) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_9
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable50
	movwf	SysStringA
	movlw	(high StringTable50) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_10
	bcf	SYSBITVAR1,6
	movlw	low StringTable50
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable50) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDOK
	goto	ENDIF6
ELSE6_10
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable29
	movwf	SysStringA
	movlw	(high StringTable29) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_LINE
	movwf	FSR0L
	movlw	high RB_LINE
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	btfss	SysByteTempX,0
	goto	ELSE6_11
	goto	ENDIF6
ELSE6_11
	movlw	low StringTable51
	movwf	SysRB_TEXTHandler
	movlw	(high StringTable51) | 128
	movwf	SysRB_TEXTHandler_H
	call	RB_GSA_SENDERR
ENDIF6
	goto	RB_LINEBUF_CLEAR

;********************************************************************************

RB_GSA_SENDDATAINT
	movlw	low StringTable35
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable35) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	SysRB_LABELHandler,W
	movwf	SysPRINTDATAHandler
	movf	SysRB_LABELHandler_H,W
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	low StringTable27
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable27) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	RB_VALUE,W
	movwf	SERPRINTVAL
	movf	RB_VALUE_H,W
	movwf	SERPRINTVAL_H
	movf	RB_VALUE_U,W
	movwf	SERPRINTVAL_U
	movf	RB_VALUE_E,W
	movwf	SERPRINTVAL_E
	movlw	1
	movwf	COMPORT
	call	HSERPRINT435
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_GSA_SENDERR
	movlw	low StringTable33
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable33) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	SysRB_TEXTHandler,W
	movwf	SysPRINTDATAHandler
	movf	SysRB_TEXTHandler_H,W
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_GSA_SENDID
	movlw	low StringTable34
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable34) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_GSA_SENDOK
	movlw	low StringTable32
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable32) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	movlw	low StringTable29
	movwf	SysStringA
	movlw	(high StringTable29) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	movlw	low RB_TEXT
	movwf	FSR0L
	movlw	high RB_TEXT
	movwf	FSR0H
	movlw	low SYSTEMPARRAY
	movwf	FSR1L
	movlw	high SYSTEMPARRAY
	movwf	FSR1H
	call	SYSCOMPEQUALSTRING
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF11
	movlw	low StringTable27
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable27) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	SysRB_TEXTHandler,W
	movwf	SysPRINTDATAHandler
	movf	SysRB_TEXTHandler_H,W
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
ENDIF11
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_LED_STATUS_INIT
	bcf	TRISC,0
	banksel	ANSELC
	bcf	ANSELC,0
	banksel	LATC
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_TOGGLE
	clrf	SysTemp1
	btfsc	LATC,0
	incf	SysTemp1,F
	comf	SysTemp1,F
	bcf	LATC,0
	btfsc	SysTemp1,0
	bsf	LATC,0
	return

;********************************************************************************

RB_LINEBUF_CLEAR
	movlw	low RB_LINE
	movwf	FSR1L
	movlw	high RB_LINE
	movwf	FSR1H
	movlw	low StringTable29
	movwf	SysStringA
	movlw	(high StringTable29) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	bcf	SYSBITVAR1,4
	clrf	RB_LINECOUNT
	bcf	SYSBITVAR1,5
	return

;********************************************************************************

RB_LINEBUF_INIT
	movlw	low RB_LINE
	movwf	FSR1L
	movlw	high RB_LINE
	movwf	FSR1H
	movlw	low StringTable29
	movwf	SysStringA
	movlw	(high StringTable29) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	bcf	SYSBITVAR1,4
	clrf	RB_LINECOUNT
	bcf	SYSBITVAR1,5
	return

;********************************************************************************

SYSCOMPEQUAL32
	clrf	SYSBYTETEMPX
	movf	SYSLONGTEMPA, W
	subwf	SYSLONGTEMPB, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_H, W
	subwf	SYSLONGTEMPB_H, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_U, W
	subwf	SYSLONGTEMPB_U, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_E, W
	subwf	SYSLONGTEMPB_E, W
	btfss	STATUS, Z
	return
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSCOMPEQUALSTRING
	clrf	SYSBYTETEMPX
	movf	INDF0, W
	movwf	SYSBYTETEMPA
	subwf	INDF1, W
	btfss	STATUS, Z
	return
	movf	SYSBYTETEMPA, F
	btfsc	STATUS, Z
	goto	SCESTRTRUE
SYSSTRINGCOMP
	addfsr	0, 1
	addfsr	1, 1
	movf	INDF0, W
	subwf	INDF1, W
	btfss	STATUS, Z
	return
	decfsz	SYSBYTETEMPA, F
	goto	SYSSTRINGCOMP
SCESTRTRUE
	comf	SYSBYTETEMPX, F
	return

;********************************************************************************

SYSDIVSUB32
	movf	SYSLONGTEMPA,W
	movwf	SYSLONGDIVMULTA
	movf	SYSLONGTEMPA_H,W
	movwf	SYSLONGDIVMULTA_H
	movf	SYSLONGTEMPA_U,W
	movwf	SYSLONGDIVMULTA_U
	movf	SYSLONGTEMPA_E,W
	movwf	SYSLONGDIVMULTA_E
	movf	SYSLONGTEMPB,W
	movwf	SYSLONGDIVMULTB
	movf	SYSLONGTEMPB_H,W
	movwf	SYSLONGDIVMULTB_H
	movf	SYSLONGTEMPB_U,W
	movwf	SYSLONGDIVMULTB_U
	movf	SYSLONGTEMPB_E,W
	movwf	SYSLONGDIVMULTB_E
	clrf	SYSLONGDIVMULTX
	clrf	SYSLONGDIVMULTX_H
	clrf	SYSLONGDIVMULTX_U
	clrf	SYSLONGDIVMULTX_E
	movf	SYSLONGDIVMULTB,W
	movwf	SysLONGTempA
	movf	SYSLONGDIVMULTB_H,W
	movwf	SysLONGTempA_H
	movf	SYSLONGDIVMULTB_U,W
	movwf	SysLONGTempA_U
	movf	SYSLONGDIVMULTB_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	btfss	SysByteTempX,0
	goto	ENDIF14
	clrf	SYSLONGTEMPA
	clrf	SYSLONGTEMPA_H
	clrf	SYSLONGTEMPA_U
	clrf	SYSLONGTEMPA_E
	return
ENDIF14
	movlw	32
	movwf	SYSDIVLOOP
SYSDIV32START
	bcf	STATUS,C
	rlf	SYSLONGDIVMULTA,F
	rlf	SYSLONGDIVMULTA_H,F
	rlf	SYSLONGDIVMULTA_U,F
	rlf	SYSLONGDIVMULTA_E,F
	rlf	SYSLONGDIVMULTX,F
	rlf	SYSLONGDIVMULTX_H,F
	rlf	SYSLONGDIVMULTX_U,F
	rlf	SYSLONGDIVMULTX_E,F
	movf	SYSLONGDIVMULTB,W
	subwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	subwfb	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	subwfb	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	subwfb	SYSLONGDIVMULTX_E,F
	bsf	SYSLONGDIVMULTA,0
	btfsc	STATUS,C
	goto	ENDIF15
	bcf	SYSLONGDIVMULTA,0
	movf	SYSLONGDIVMULTB,W
	addwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	addwfc	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	addwfc	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	addwfc	SYSLONGDIVMULTX_E,F
ENDIF15
	decfsz	SYSDIVLOOP, F
	goto	SYSDIV32START
	movf	SYSLONGDIVMULTA,W
	movwf	SYSLONGTEMPA
	movf	SYSLONGDIVMULTA_H,W
	movwf	SYSLONGTEMPA_H
	movf	SYSLONGDIVMULTA_U,W
	movwf	SYSLONGTEMPA_U
	movf	SYSLONGDIVMULTA_E,W
	movwf	SYSLONGTEMPA_E
	movf	SYSLONGDIVMULTX,W
	movwf	SYSLONGTEMPX
	movf	SYSLONGDIVMULTX_H,W
	movwf	SYSLONGTEMPX_H
	movf	SYSLONGDIVMULTX_U,W
	movwf	SYSLONGTEMPX_U
	movf	SYSLONGDIVMULTX_E,W
	movwf	SYSLONGTEMPX_E
	return

;********************************************************************************

SYSREADSTRING
	call	SYSSTRINGTABLES
	movwf	SYSCALCTEMPA
	movwf	INDF1
	goto	SYSSTRINGREADCHECK
SYSREADSTRINGPART
	call	SYSSTRINGTABLES
	movwf	SYSCALCTEMPA
	addwf	SYSSTRINGLENGTH,F
SYSSTRINGREADCHECK
	movf	SYSCALCTEMPA,F
	btfsc	STATUS,Z
	return
SYSSTRINGREAD
	call	SYSSTRINGTABLES
	addfsr	1,1
	movwf	INDF1
	decfsz	SYSCALCTEMPA, F
	goto	SYSSTRINGREAD
	return

;********************************************************************************

SysStringTables
	movf	SysStringA_H,W
	movwf	PCLATH
	movf	SysStringA,W
	incf	SysStringA,F
	btfsc	STATUS,Z
	incf	SysStringA_H,F
	movwf	PCL

StringTable27
	retlw	1
	retlw	32	; 


StringTable29
	retlw	0


StringTable32
	retlw	2
	retlw	79	;O
	retlw	75	;K


StringTable33
	retlw	4
	retlw	69	;E
	retlw	82	;R
	retlw	82	;R
	retlw	32	; 


StringTable34
	retlw	39
	retlw	73	;I
	retlw	68	;D
	retlw	32	; 
	retlw	78	;N
	retlw	85	;U
	retlw	71	;G
	retlw	71	;G
	retlw	69	;E
	retlw	84	;T
	retlw	45	;-
	retlw	82	;R
	retlw	69	;E
	retlw	68	;D
	retlw	66	;B
	retlw	79	;O
	retlw	65	;A
	retlw	82	;R
	retlw	68	;D
	retlw	32	; 
	retlw	80	;P
	retlw	73	;I
	retlw	67	;C
	retlw	49	;1
	retlw	54	;6
	retlw	70	;F
	retlw	49	;1
	retlw	56	;8
	retlw	52	;4
	retlw	50	;2
	retlw	52	;4
	retlw	32	; 
	retlw	70	;F
	retlw	87	;W
	retlw	61	; (equals)
	retlw	48	;0
	retlw	46	;.
	retlw	49	;1
	retlw	46	;.
	retlw	48	;0


StringTable35
	retlw	5
	retlw	68	;D
	retlw	65	;A
	retlw	84	;T
	retlw	65	;A
	retlw	32	; 


StringTable37
	retlw	13
	retlw	76	;L
	retlw	73	;I
	retlw	78	;N
	retlw	69	;E
	retlw	95	;_
	retlw	84	;T
	retlw	79	;O
	retlw	79	;O
	retlw	95	;_
	retlw	76	;L
	retlw	79	;O
	retlw	78	;N
	retlw	71	;G


StringTable38
	retlw	5
	retlw	72	;H
	retlw	69	;E
	retlw	76	;L
	retlw	76	;L
	retlw	79	;O


StringTable39
	retlw	3
	retlw	73	;I
	retlw	68	;D
	retlw	63	;?


StringTable40
	retlw	6
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	84	;T
	retlw	85	;U
	retlw	83	;S


StringTable41
	retlw	14
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	84	;T
	retlw	85	;U
	retlw	83	;S
	retlw	32	; 
	retlw	82	;R
	retlw	85	;U
	retlw	78	;N
	retlw	78	;N
	retlw	73	;I
	retlw	78	;N
	retlw	71	;G


StringTable42
	retlw	12
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	84	;T
	retlw	85	;U
	retlw	83	;S
	retlw	32	; 
	retlw	82	;R
	retlw	69	;E
	retlw	65	;A
	retlw	68	;D
	retlw	89	;Y


StringTable43
	retlw	5
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	82	;R
	retlw	84	;T


StringTable44
	retlw	4
	retlw	83	;S
	retlw	84	;T
	retlw	79	;O
	retlw	80	;P


StringTable45
	retlw	5
	retlw	82	;R
	retlw	69	;E
	retlw	83	;S
	retlw	69	;E
	retlw	84	;T


StringTable46
	retlw	4
	retlw	84	;T
	retlw	65	;A
	retlw	82	;R
	retlw	69	;E


StringTable47
	retlw	4
	retlw	82	;R
	retlw	69	;E
	retlw	65	;A
	retlw	68	;D


StringTable48
	retlw	3
	retlw	65	;A
	retlw	68	;D
	retlw	67	;C


StringTable49
	retlw	7
	retlw	68	;D
	retlw	69	;E
	retlw	77	;M
	retlw	79	;O
	retlw	32	; 
	retlw	79	;O
	retlw	78	;N


StringTable50
	retlw	8
	retlw	68	;D
	retlw	69	;E
	retlw	77	;M
	retlw	79	;O
	retlw	32	; 
	retlw	79	;O
	retlw	70	;F
	retlw	70	;F


StringTable51
	retlw	7
	retlw	66	;B
	retlw	65	;A
	retlw	68	;D
	retlw	95	;_
	retlw	67	;C
	retlw	77	;M
	retlw	68	;D


;********************************************************************************

;Program_memory_page: 1
	ORG	2048

 END
