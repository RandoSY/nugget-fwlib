;Program compiled by GCBASIC (2025.01.10 (Windows 32 bit) : Build 1450) for Microchip MPASM/MPLAB-X Assembler using FreeBASIC 1.09.0/2026-05-03 CRC247
;Need help? 
;  Please donate to help support the operational costs of the project.  Donate via https://gcbasic.com/donate/
;  
;  See the GCBASIC forums at http://sourceforge.net/projects/gcbasic/forums,
;  Check the documentation and Help at http://gcbasic.sourceforge.net/help/,
;or, email us:
;   evanvennn at users dot sourceforge dot net
;********************************************************************************
;   Installation Dir : C:\Users\rasyoung\Desktop\DIY Tech For Experiments\Nugget\Pursuing the Nugget\nugget_frequency_meter_source\artifacts\toolchain-src\GCBASIC
;   Source file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\020_full_tiny_gsa_node\020_full_tiny_gsa_node.gcb
;   Setting file     : 
;   Preserve mode    : 0
;   Assembler        : 
;   Programmer       : 
;   Output file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\020_full_tiny_gsa_node\020_full_tiny_gsa_node.asm
;   Float Capability : 
;********************************************************************************

;Set up the assembler options (Chip type, clock source, other bits and pieces)
 LIST p=16F18424, r=DEC
 TITLE       "C:\Users\rasyoung\Desktop\nugget-fwlib\examples\020_full_tiny_gsa_node\020_full_tiny_gsa_node.gcb"
 SUBTITLE    "05-24-2026 16:58:23"
#include <P16F18424.inc>
 __CONFIG _CONFIG1, _FCMEN_ON & _CLKOUTEN_OFF & _RSTOSC_HFINT32 & _FEXTOSC_OFF
 __CONFIG _CONFIG2, _MCLRE_ON
 __CONFIG _CONFIG3, _WDTE_OFF
 __CONFIG _CONFIG4, _LVP_ON & _WRTSAF_OFF & _WRTD_OFF & _WRTB_OFF
 __CONFIG _CONFIG5, _CP_OFF

;********************************************************************************

;Set aside memory locations for variables
;  Shared/Access RAM = (SA)
ADREADPORT                       EQU      32          ; 0x20
ANSELB                           EQU      33          ; 0x21
COMPORT                          EQU      34          ; 0x22
DELAYTEMP                        EQU     112          ; 0x70 (SA)
DELAYTEMP2                       EQU     113          ; 0x71 (SA)
HSERPRINTCRLFCOUNT               EQU      35          ; 0x23
OUTVALUETEMP                     EQU      36          ; 0x24
PRINTLEN                         EQU      37          ; 0x25
RB_ADC_READAVERAGE_AN2           EQU      38          ; 0x26
RB_ADC_READAVERAGE_AN2_H         EQU      39          ; 0x27
RB_I                             EQU      40          ; 0x28
RB_SAMPLES                       EQU      41          ; 0x29
RB_TOTAL                         EQU      42          ; 0x2A
RB_TOTAL_E                       EQU      45          ; 0x2D
RB_TOTAL_H                       EQU      43          ; 0x2B
RB_TOTAL_U                       EQU      44          ; 0x2C
READAD                           EQU      46          ; 0x2E
SAMPLE                           EQU      47          ; 0x2F
SAMPLE_E                         EQU      50          ; 0x32
SAMPLE_H                         EQU      48          ; 0x30
SAMPLE_U                         EQU      49          ; 0x31
SERDATA                          EQU      51          ; 0x33
SERPRINTVAL                      EQU      52          ; 0x34
SERPRINTVAL_E                    EQU      55          ; 0x37
SERPRINTVAL_H                    EQU      53          ; 0x35
SERPRINTVAL_U                    EQU      54          ; 0x36
STRINGPOINTER                    EQU      56          ; 0x38
SYSBITVAR0                       EQU      57          ; 0x39
SYSBYTETEMPX                     EQU     112          ; 0x70 (SA)
SYSCALCTEMPA                     EQU     117          ; 0x75 (SA)
SYSCALCTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSCALCTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSCALCTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSCALCTEMPX                     EQU     112          ; 0x70 (SA)
SYSCALCTEMPX_H                   EQU     113          ; 0x71 (SA)
SYSDIVLOOP                       EQU     116          ; 0x74 (SA)
SYSDIVMULTA                      EQU     119          ; 0x77 (SA)
SYSDIVMULTA_H                    EQU     120          ; 0x78 (SA)
SYSDIVMULTB                      EQU     123          ; 0x7B (SA)
SYSDIVMULTB_H                    EQU     124          ; 0x7C (SA)
SYSDIVMULTX                      EQU     114          ; 0x72 (SA)
SYSDIVMULTX_H                    EQU     115          ; 0x73 (SA)
SYSLONGDIVMULTA                  EQU      58          ; 0x3A
SYSLONGDIVMULTA_E                EQU      61          ; 0x3D
SYSLONGDIVMULTA_H                EQU      59          ; 0x3B
SYSLONGDIVMULTA_U                EQU      60          ; 0x3C
SYSLONGDIVMULTB                  EQU      62          ; 0x3E
SYSLONGDIVMULTB_E                EQU      65          ; 0x41
SYSLONGDIVMULTB_H                EQU      63          ; 0x3F
SYSLONGDIVMULTB_U                EQU      64          ; 0x40
SYSLONGDIVMULTX                  EQU      66          ; 0x42
SYSLONGDIVMULTX_E                EQU      69          ; 0x45
SYSLONGDIVMULTX_H                EQU      67          ; 0x43
SYSLONGDIVMULTX_U                EQU      68          ; 0x44
SYSLONGTEMPA                     EQU     117          ; 0x75 (SA)
SYSLONGTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSLONGTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSLONGTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSLONGTEMPB                     EQU     121          ; 0x79 (SA)
SYSLONGTEMPB_E                   EQU     124          ; 0x7C (SA)
SYSLONGTEMPB_H                   EQU     122          ; 0x7A (SA)
SYSLONGTEMPB_U                   EQU     123          ; 0x7B (SA)
SYSLONGTEMPX                     EQU     112          ; 0x70 (SA)
SYSLONGTEMPX_E                   EQU     115          ; 0x73 (SA)
SYSLONGTEMPX_H                   EQU     113          ; 0x71 (SA)
SYSLONGTEMPX_U                   EQU     114          ; 0x72 (SA)
SYSPRINTBUFFER                   EQU    8677          ; 0x21E5
SYSPRINTBUFFLEN                  EQU      70          ; 0x46
SYSPRINTDATAHANDLER              EQU      71          ; 0x47
SYSPRINTDATAHANDLER_H            EQU      72          ; 0x48
SYSPRINTTEMP                     EQU      73          ; 0x49
SYSREPEATTEMP1                   EQU      74          ; 0x4A
SYSSTRINGA                       EQU     119          ; 0x77 (SA)
SYSSTRINGA_H                     EQU     120          ; 0x78 (SA)
SYSTEMP1                         EQU      75          ; 0x4B
SYSTEMP1_E                       EQU      78          ; 0x4E
SYSTEMP1_H                       EQU      76          ; 0x4C
SYSTEMP1_U                       EQU      77          ; 0x4D
SYSWAITTEMP10US                  EQU     117          ; 0x75 (SA)
SYSWAITTEMPMS                    EQU     114          ; 0x72 (SA)
SYSWAITTEMPMS_H                  EQU     115          ; 0x73 (SA)
SYSWORDTEMPA                     EQU     117          ; 0x75 (SA)
SYSWORDTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSWORDTEMPB                     EQU     121          ; 0x79 (SA)
SYSWORDTEMPB_H                   EQU     122          ; 0x7A (SA)
SYSWORDTEMPX                     EQU     112          ; 0x70 (SA)
SYSWORDTEMPX_H                   EQU     113          ; 0x71 (SA)
VALUE                            EQU      79          ; 0x4F
VALUE_H                          EQU      80          ; 0x50

;********************************************************************************

;Alias variables
AFSR0 EQU 4
AFSR0_H EQU 5
SYSREADADBYTE EQU 46

;********************************************************************************

;Vectors
	ORG	0
	pagesel	BASPROGRAMSTART
	goto	BASPROGRAMSTART
	ORG	4
	retfie

;********************************************************************************

;Program_memory_page: 0
	ORG	5
BASPROGRAMSTART
;Call initialisation routines
	call	INITSYS
	call	INITUSART

;Start_of_the_main_program
	call	RB_CORE_INIT
	call	RB_SW1_INITPULLUP
	call	RB_LED_STATUS_INIT
	call	RB_ADC_INIT
	bcf	SYSBITVAR0,0
	clrf	SAMPLE
	clrf	SAMPLE_H
	clrf	SAMPLE_U
	clrf	SAMPLE_E
	movlw	low StringTable5
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable5) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
	movlw	low StringTable6
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable6) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
SysDoLoop_S1
	call	FN_RB_SW1_PRESSEDEVENT
	btfss	SYSBITVAR0,6
	goto	ENDIF1
	btfss	SYSBITVAR0,0
	goto	ELSE3_1
	bcf	SYSBITVAR0,0
	movlw	low StringTable7
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable7) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
	goto	ENDIF3
ELSE3_1
	bsf	SYSBITVAR0,0
	movlw	low StringTable8
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable8) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
ENDIF3
	call	RB_SW1_WAITFORRELEASE
ENDIF1
	btfss	SYSBITVAR0,0
	goto	ELSE2_1
	movlw	8
	movwf	RB_SAMPLES
	call	FN_RB_ADC_READAVERAGE_AN2
	movf	RB_ADC_READAVERAGE_AN2,W
	movwf	VALUE
	movf	RB_ADC_READAVERAGE_AN2_H,W
	movwf	VALUE_H
	movlw	low StringTable9
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable9) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movf	SAMPLE,W
	movwf	SERPRINTVAL
	movf	SAMPLE_H,W
	movwf	SERPRINTVAL_H
	movf	SAMPLE_U,W
	movwf	SERPRINTVAL_U
	movf	SAMPLE_E,W
	movwf	SERPRINTVAL_E
	movlw	1
	movwf	COMPORT
	call	HSERPRINT375
	movlw	low StringTable10
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable10) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT370
	movf	VALUE,W
	movwf	SERPRINTVAL
	movf	VALUE_H,W
	movwf	SERPRINTVAL_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT373
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
	incf	SAMPLE,F
	btfsc	STATUS,Z
	incf	SAMPLE_H,F
	btfsc	STATUS,Z
	incf	SAMPLE_U,F
	btfsc	STATUS,Z
	incf	SAMPLE_E,F
	call	RB_LED_STATUS_TOGGLE
	movlw	244
	movwf	SysWaitTempMS
	movlw	1
	movwf	SysWaitTempMS_H
	call	Delay_MS
	goto	ENDIF2
ELSE2_1
	call	RB_LED_STATUS_OFF
	movlw	50
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
ENDIF2
	goto	SysDoLoop_S1
SysDoLoop_E1
BASPROGRAMEND
	sleep
	goto	BASPROGRAMEND

;********************************************************************************

Delay_10US
D10US_START
	movlw	25
	movwf	DELAYTEMP
DelayUS0
	decfsz	DELAYTEMP,F
	goto	DelayUS0
	nop
	decfsz	SysWaitTemp10US, F
	goto	D10US_START
	return

;********************************************************************************

Delay_MS
	incf	SysWaitTempMS_H, F
DMS_START
	movlw	14
	movwf	DELAYTEMP2
DMS_OUTER
	movlw	189
	movwf	DELAYTEMP
DMS_INNER
	decfsz	DELAYTEMP, F
	goto	DMS_INNER
	decfsz	DELAYTEMP2, F
	goto	DMS_OUTER
	decfsz	SysWaitTempMS, F
	goto	DMS_START
	decfsz	SysWaitTempMS_H, F
	goto	DMS_START
	return

;********************************************************************************

HSERPRINT370
	movf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movf	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	PRINTLEN
	movf	PRINTLEN,F
	btfsc	STATUS, Z
	goto	ENDIF16
	clrf	SYSPRINTTEMP
	movlw	1
	subwf	PRINTLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd2
SysForLoop2
	incf	SYSPRINTTEMP,F
	movf	SYSPRINTTEMP,W
	addwf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movlw	0
	addwfc	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	SERDATA
	call	HSERSEND358
	movf	PRINTLEN,W
	subwf	SYSPRINTTEMP,W
	btfss	STATUS, C
	goto	SysForLoop2
SysForLoopEnd2
ENDIF16
	return

;********************************************************************************

HSERPRINT373
	clrf	OUTVALUETEMP
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	16
	movwf	SysWORDTempB
	movlw	39
	movwf	SysWORDTempB_H
	call	SYSCOMPLESSTHAN16
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF19
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	16
	movwf	SysWORDTempB
	movlw	39
	movwf	SysWORDTempB_H
	call	SYSDIVSUB16
	movf	SysWORDTempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPX_H,W
	movwf	SERPRINTVAL_H
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND358
	goto	HSERPRINTWORD1000
ENDIF19
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	232
	movwf	SysWORDTempB
	movlw	3
	movwf	SysWORDTempB_H
	call	SYSCOMPLESSTHAN16
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF20
HSERPRINTWORD1000
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	232
	movwf	SysWORDTempB
	movlw	3
	movwf	SysWORDTempB_H
	call	SYSDIVSUB16
	movf	SysWORDTempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPX_H,W
	movwf	SERPRINTVAL_H
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND358
	goto	HSERPRINTWORD100
ENDIF20
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	100
	movwf	SysWORDTempB
	clrf	SysWORDTempB_H
	call	SYSCOMPLESSTHAN16
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF21
HSERPRINTWORD100
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	100
	movwf	SysWORDTempB
	clrf	SysWORDTempB_H
	call	SYSDIVSUB16
	movf	SysWORDTempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPX_H,W
	movwf	SERPRINTVAL_H
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND358
	goto	HSERPRINTWORD10
ENDIF21
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	10
	movwf	SysWORDTempB
	clrf	SysWORDTempB_H
	call	SYSCOMPLESSTHAN16
	comf	SysByteTempX,F
	btfss	SysByteTempX,0
	goto	ENDIF22
HSERPRINTWORD10
	movf	SERPRINTVAL,W
	movwf	SysWORDTempA
	movf	SERPRINTVAL_H,W
	movwf	SysWORDTempA_H
	movlw	10
	movwf	SysWORDTempB
	clrf	SysWORDTempB_H
	call	SYSDIVSUB16
	movf	SysWORDTempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPX_H,W
	movwf	SERPRINTVAL_H
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND358
ENDIF22
	movf	SERPRINTVAL,W
	movwf	OUTVALUETEMP
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	goto	HSERSEND358

;********************************************************************************

HSERPRINT375
	clrf	SYSPRINTBUFFLEN
SysDoLoop_S3
	incf	SYSPRINTBUFFLEN,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTBUFFLEN,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movf	SERPRINTVAL,W
	movwf	SysLONGTempA
	movf	SERPRINTVAL_H,W
	movwf	SysLONGTempA_H
	movf	SERPRINTVAL_U,W
	movwf	SysLONGTempA_U
	movf	SERPRINTVAL_E,W
	movwf	SysLONGTempA_E
	movlw	10
	movwf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSDIVSUB32
	movf	SysLONGTempX,W
	movwf	INDF0
	movf	SYSCALCTEMPA,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPA_H,W
	movwf	SERPRINTVAL_H
	movf	SYSCALCTEMPA_U,W
	movwf	SERPRINTVAL_U
	movf	SYSCALCTEMPA_E,W
	movwf	SERPRINTVAL_E
	movf	serprintval,W
	movwf	SysLONGTempA
	movf	serprintval_H,W
	movwf	SysLONGTempA_H
	movf	serprintval_U,W
	movwf	SysLONGTempA_U
	movf	serprintval_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	comf	SysByteTempX,F
	btfsc	SysByteTempX,0
	goto	SysDoLoop_S3
SysDoLoop_E3
	incf	SYSPRINTBUFFLEN,W
	movwf	SYSPRINTTEMP
	movlw	1
	subwf	SYSPRINTBUFFLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd3
SysForLoop3
	decf	SYSPRINTTEMP,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTTEMP,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movlw	48
	addwf	INDF0,W
	movwf	SERDATA
	call	HSERSEND358
	movf	SYSPRINTTEMP,W
	sublw	1
	btfss	STATUS, C
	goto	SysForLoop3
SysForLoopEnd3
	return

;********************************************************************************

HSERPRINTCRLF
	movf	HSERPRINTCRLFCOUNT,W
	movwf	SysRepeatTemp1
	btfsc	STATUS,Z
	goto	SysRepeatLoopEnd1
SysRepeatLoop1
	movlw	13
	movwf	SERDATA
	call	HSERSEND358
	movlw	10
	movwf	SERDATA
	call	HSERSEND358
	decfsz	SysRepeatTemp1,F
	goto	SysRepeatLoop1
SysRepeatLoopEnd1
	return

;********************************************************************************

HSERSEND358
HSERSENDUSART1HANDLER
	movf	SERDATA,W
	banksel	TXREG
	movwf	TXREG
	movlw	1
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	banksel	STATUS
	goto	Delay_MS

;********************************************************************************

INITSYS
;Default settings for microcontrollers with _OSCCON1_
	movlw	96
	banksel	OSCCON1
	movwf	OSCCON1
	clrf	OSCCON3
	clrf	OSCEN
	clrf	OSCTUNE
;The MCU is a chip family ChipFamily
;OSCCON type is 102
	movlw	6
	movwf	OSCFRQ
;_Complete_the_chip_setup_of_BSR_ADCs_ANSEL_and_other_key_setup_registers_or_register_bits
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	CM2CON0
	bcf	CM2CON0,C2EN
	bcf	CM1CON0,C1EN
	banksel	PORTA
	clrf	PORTA
	clrf	PORTC
	return

;********************************************************************************

INITUSART
	movlw	3
	banksel	SP1BRGH
	movwf	SP1BRGH
	movlw	64
	movwf	SP1BRGL
	movlw	64
	movwf	SPBRG
	bsf	BAUD1CON,BRG16
	bsf	TX1STA,BRGH
	bcf	TX1STA,SYNC_TX1STA
	bsf	TX1STA,TXEN
	bsf	RC1STA,SPEN
	bsf	RC1STA,CREN
	bsf	RC1STA,CREN
	banksel	STATUS
	return

;********************************************************************************

RB_ADC_INIT
	bsf	TRISA,2
	banksel	ANSELA
	bsf	ANSELA,2
	banksel	STATUS
	return

;********************************************************************************

FN_RB_ADC_READAVERAGE_AN2
	clrf	RB_TOTAL
	clrf	RB_TOTAL_H
	clrf	RB_TOTAL_U
	clrf	RB_TOTAL_E
	clrf	RB_I
	movlw	1
	subwf	RB_SAMPLES,W
	btfss	STATUS, C
	goto	SysForLoopEnd1
SysForLoop1
	incf	RB_I,F
	movlw	2
	movwf	ADREADPORT
	call	FN_READAD26
	movf	SYSREADADBYTE,W
	addwf	RB_TOTAL,F
	movlw	0
	addwfc	RB_TOTAL_H,F
	movlw	0
	addwfc	RB_TOTAL_U,F
	movlw	0
	addwfc	RB_TOTAL_E,F
	movlw	2
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	movf	RB_SAMPLES,W
	subwf	RB_I,W
	btfss	STATUS, C
	goto	SysForLoop1
SysForLoopEnd1
	movf	RB_TOTAL,W
	movwf	SysLONGTempA
	movf	RB_TOTAL_H,W
	movwf	SysLONGTempA_H
	movf	RB_TOTAL_U,W
	movwf	SysLONGTempA_U
	movf	RB_TOTAL_E,W
	movwf	SysLONGTempA_E
	movf	RB_SAMPLES,W
	movwf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSDIVSUB32
	movf	SysLONGTempA,W
	movwf	RB_ADC_READAVERAGE_AN2
	movf	SysLONGTempA_H,W
	movwf	RB_ADC_READAVERAGE_AN2_H
	return

;********************************************************************************

RB_CORE_ALLDIGITAL
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	STATUS
	return

;********************************************************************************

RB_CORE_CLEARLATCHES
	clrf	LATA
	clrf	LATC
	return

;********************************************************************************

RB_CORE_INIT
	call	RB_CORE_ALLDIGITAL
	goto	RB_CORE_CLEARLATCHES

;********************************************************************************

RB_LED_STATUS_INIT
	bcf	TRISC,0
	banksel	ANSELC
	bcf	ANSELC,0
	banksel	LATC
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_OFF
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_TOGGLE
	clrf	SysTemp1
	btfsc	LATC,0
	incf	SysTemp1,F
	comf	SysTemp1,F
	bcf	LATC,0
	btfsc	SysTemp1,0
	bsf	LATC,0
	return

;********************************************************************************

RB_SW1_INITPULLUP
	bsf	TRISA,0
	banksel	ANSELA
	bcf	ANSELA,0
	bsf	WPUA,0
	banksel	SYSBITVAR0
	bcf	SYSBITVAR0,1
	btfsc	PORTA,0
	bsf	SYSBITVAR0,1
	bcf	SYSBITVAR0,2
	return

;********************************************************************************

FN_RB_SW1_PRESSEDEVENT
	bcf	SYSBITVAR0,6
	btfss	SYSBITVAR0,1
	goto	ENDIF5
	btfsc	PORTA,0
	goto	ENDIF6
	movlw	20
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	btfss	PORTA,0
	bsf	SYSBITVAR0,6
ENDIF6
ENDIF5
	bcf	SYSBITVAR0,1
	btfsc	PORTA,0
	bsf	SYSBITVAR0,1
	return

;********************************************************************************

RB_SW1_WAITFORRELEASE
SysDoLoop_S2
	btfsc	PORTA,0
	goto	SysDoLoop_E2
	goto	SysDoLoop_S2
SysDoLoop_E2
	movlw	20
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	goto	Delay_MS

;********************************************************************************

FN_READAD26
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	banksel	ADREADPORT
	movf	ADREADPORT,W
	banksel	ADPCH
	movwf	ADPCH
SysSelect1Case1
	banksel	ADREADPORT
	movf	ADREADPORT,F
	btfss	STATUS, Z
	goto	SysSelect1Case2
	banksel	ANSELA
	bsf	ANSELA,0
	goto	SysSelectEnd1
SysSelect1Case2
	decf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case3
	banksel	ANSELA
	bsf	ANSELA,1
	goto	SysSelectEnd1
SysSelect1Case3
	movlw	2
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case4
	banksel	ANSELA
	bsf	ANSELA,2
	goto	SysSelectEnd1
SysSelect1Case4
	movlw	3
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case5
	banksel	ANSELA
	bsf	ANSELA,3
	goto	SysSelectEnd1
SysSelect1Case5
	movlw	4
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case6
	banksel	ANSELA
	bsf	ANSELA,4
	goto	SysSelectEnd1
SysSelect1Case6
	movlw	5
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case7
	banksel	ANSELA
	bsf	ANSELA,5
	goto	SysSelectEnd1
SysSelect1Case7
	movlw	6
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case8
	banksel	ANSELA
	bsf	ANSELA,6
	goto	SysSelectEnd1
SysSelect1Case8
	movlw	7
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case9
	banksel	ANSELA
	bsf	ANSELA,7
	goto	SysSelectEnd1
SysSelect1Case9
	movlw	8
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case10
	bsf	ANSELB,0
	goto	SysSelectEnd1
SysSelect1Case10
	movlw	9
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case11
	bsf	ANSELB,1
	goto	SysSelectEnd1
SysSelect1Case11
	movlw	10
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case12
	bsf	ANSELB,2
	goto	SysSelectEnd1
SysSelect1Case12
	movlw	11
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case13
	bsf	ANSELB,3
	goto	SysSelectEnd1
SysSelect1Case13
	movlw	12
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case14
	bsf	ANSELB,4
	goto	SysSelectEnd1
SysSelect1Case14
	movlw	13
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case15
	bsf	ANSELB,5
	goto	SysSelectEnd1
SysSelect1Case15
	movlw	14
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case16
	bsf	ANSELB,6
	goto	SysSelectEnd1
SysSelect1Case16
	movlw	15
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case17
	bsf	ANSELB,7
	goto	SysSelectEnd1
SysSelect1Case17
	movlw	16
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case18
	banksel	ANSELC
	bsf	ANSELC,0
	goto	SysSelectEnd1
SysSelect1Case18
	movlw	17
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case19
	banksel	ANSELC
	bsf	ANSELC,1
	goto	SysSelectEnd1
SysSelect1Case19
	movlw	18
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case20
	banksel	ANSELC
	bsf	ANSELC,2
	goto	SysSelectEnd1
SysSelect1Case20
	movlw	19
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case21
	banksel	ANSELC
	bsf	ANSELC,3
	goto	SysSelectEnd1
SysSelect1Case21
	movlw	20
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case22
	banksel	ANSELC
	bsf	ANSELC,4
	goto	SysSelectEnd1
SysSelect1Case22
	movlw	21
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case23
	banksel	ANSELC
	bsf	ANSELC,5
	goto	SysSelectEnd1
SysSelect1Case23
	movlw	22
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case24
	banksel	ANSELC
	bsf	ANSELC,6
	goto	SysSelectEnd1
SysSelect1Case24
	movlw	23
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelectEnd1
	banksel	ANSELC
	bsf	ANSELC,7
SysSelectEnd1
	banksel	ADCON0
	bcf	ADCON0,ADCS
	movlw	1
	movwf	ADCLK
	bcf	ADCON0,ADCS
	movlw	15
	movwf	ADCLK
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADFM0
	banksel	ADREADPORT
	movf	ADREADPORT,W
	banksel	ADPCH
	movwf	ADPCH
	banksel	ADCON0
	bsf	ADCON0,ADON
	movlw	2
	movwf	SysWaitTemp10US
	banksel	STATUS
	call	Delay_10US
	banksel	ADCON0
	bsf	ADCON0,GO_NOT_DONE
	nop
SysWaitLoop1
	btfsc	ADCON0,GO_NOT_DONE
	goto	SysWaitLoop1
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	ADRESH
	movf	ADRESH,W
	banksel	READAD
	movwf	READAD
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	banksel	STATUS
	return

;********************************************************************************

SYSCOMPEQUAL16
	clrf	SYSBYTETEMPX
	movf	SYSWORDTEMPA, W
	subwf	SYSWORDTEMPB, W
	btfss	STATUS, Z
	return
	movf	SYSWORDTEMPA_H, W
	subwf	SYSWORDTEMPB_H, W
	btfss	STATUS, Z
	return
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSCOMPEQUAL32
	clrf	SYSBYTETEMPX
	movf	SYSLONGTEMPA, W
	subwf	SYSLONGTEMPB, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_H, W
	subwf	SYSLONGTEMPB_H, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_U, W
	subwf	SYSLONGTEMPB_U, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_E, W
	subwf	SYSLONGTEMPB_E, W
	btfss	STATUS, Z
	return
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSCOMPLESSTHAN16
	clrf	SYSBYTETEMPX
	movf	SYSWORDTEMPA_H,W
	subwf	SYSWORDTEMPB_H,W
	btfss	STATUS,C
	return
	movf	SYSWORDTEMPB_H,W
	subwf	SYSWORDTEMPA_H,W
	btfss	STATUS,C
	goto	SCLT16TRUE
	movf	SYSWORDTEMPB,W
	subwf	SYSWORDTEMPA,W
	btfsc	STATUS,C
	return
SCLT16TRUE
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSDIVSUB16
	movf	SYSWORDTEMPA,W
	movwf	SYSDIVMULTA
	movf	SYSWORDTEMPA_H,W
	movwf	SYSDIVMULTA_H
	movf	SYSWORDTEMPB,W
	movwf	SYSDIVMULTB
	movf	SYSWORDTEMPB_H,W
	movwf	SYSDIVMULTB_H
	clrf	SYSDIVMULTX
	clrf	SYSDIVMULTX_H
	movf	SYSDIVMULTB,W
	movwf	SysWORDTempA
	movf	SYSDIVMULTB_H,W
	movwf	SysWORDTempA_H
	clrf	SysWORDTempB
	clrf	SysWORDTempB_H
	call	SYSCOMPEQUAL16
	btfss	SysByteTempX,0
	goto	ENDIF25
	clrf	SYSWORDTEMPA
	clrf	SYSWORDTEMPA_H
	return
ENDIF25
	movlw	16
	movwf	SYSDIVLOOP
SYSDIV16START
	bcf	STATUS,C
	rlf	SYSDIVMULTA,F
	rlf	SYSDIVMULTA_H,F
	rlf	SYSDIVMULTX,F
	rlf	SYSDIVMULTX_H,F
	movf	SYSDIVMULTB,W
	subwf	SYSDIVMULTX,F
	movf	SYSDIVMULTB_H,W
	subwfb	SYSDIVMULTX_H,F
	bsf	SYSDIVMULTA,0
	btfsc	STATUS,C
	goto	ENDIF26
	bcf	SYSDIVMULTA,0
	movf	SYSDIVMULTB,W
	addwf	SYSDIVMULTX,F
	movf	SYSDIVMULTB_H,W
	addwfc	SYSDIVMULTX_H,F
ENDIF26
	decfsz	SYSDIVLOOP, F
	goto	SYSDIV16START
	movf	SYSDIVMULTA,W
	movwf	SYSWORDTEMPA
	movf	SYSDIVMULTA_H,W
	movwf	SYSWORDTEMPA_H
	movf	SYSDIVMULTX,W
	movwf	SYSWORDTEMPX
	movf	SYSDIVMULTX_H,W
	movwf	SYSWORDTEMPX_H
	return

;********************************************************************************

SYSDIVSUB32
	movf	SYSLONGTEMPA,W
	movwf	SYSLONGDIVMULTA
	movf	SYSLONGTEMPA_H,W
	movwf	SYSLONGDIVMULTA_H
	movf	SYSLONGTEMPA_U,W
	movwf	SYSLONGDIVMULTA_U
	movf	SYSLONGTEMPA_E,W
	movwf	SYSLONGDIVMULTA_E
	movf	SYSLONGTEMPB,W
	movwf	SYSLONGDIVMULTB
	movf	SYSLONGTEMPB_H,W
	movwf	SYSLONGDIVMULTB_H
	movf	SYSLONGTEMPB_U,W
	movwf	SYSLONGDIVMULTB_U
	movf	SYSLONGTEMPB_E,W
	movwf	SYSLONGDIVMULTB_E
	clrf	SYSLONGDIVMULTX
	clrf	SYSLONGDIVMULTX_H
	clrf	SYSLONGDIVMULTX_U
	clrf	SYSLONGDIVMULTX_E
	movf	SYSLONGDIVMULTB,W
	movwf	SysLONGTempA
	movf	SYSLONGDIVMULTB_H,W
	movwf	SysLONGTempA_H
	movf	SYSLONGDIVMULTB_U,W
	movwf	SysLONGTempA_U
	movf	SYSLONGDIVMULTB_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	btfss	SysByteTempX,0
	goto	ENDIF14
	clrf	SYSLONGTEMPA
	clrf	SYSLONGTEMPA_H
	clrf	SYSLONGTEMPA_U
	clrf	SYSLONGTEMPA_E
	return
ENDIF14
	movlw	32
	movwf	SYSDIVLOOP
SYSDIV32START
	bcf	STATUS,C
	rlf	SYSLONGDIVMULTA,F
	rlf	SYSLONGDIVMULTA_H,F
	rlf	SYSLONGDIVMULTA_U,F
	rlf	SYSLONGDIVMULTA_E,F
	rlf	SYSLONGDIVMULTX,F
	rlf	SYSLONGDIVMULTX_H,F
	rlf	SYSLONGDIVMULTX_U,F
	rlf	SYSLONGDIVMULTX_E,F
	movf	SYSLONGDIVMULTB,W
	subwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	subwfb	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	subwfb	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	subwfb	SYSLONGDIVMULTX_E,F
	bsf	SYSLONGDIVMULTA,0
	btfsc	STATUS,C
	goto	ENDIF15
	bcf	SYSLONGDIVMULTA,0
	movf	SYSLONGDIVMULTB,W
	addwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	addwfc	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	addwfc	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	addwfc	SYSLONGDIVMULTX_E,F
ENDIF15
	decfsz	SYSDIVLOOP, F
	goto	SYSDIV32START
	movf	SYSLONGDIVMULTA,W
	movwf	SYSLONGTEMPA
	movf	SYSLONGDIVMULTA_H,W
	movwf	SYSLONGTEMPA_H
	movf	SYSLONGDIVMULTA_U,W
	movwf	SYSLONGTEMPA_U
	movf	SYSLONGDIVMULTA_E,W
	movwf	SYSLONGTEMPA_E
	movf	SYSLONGDIVMULTX,W
	movwf	SYSLONGTEMPX
	movf	SYSLONGDIVMULTX_H,W
	movwf	SYSLONGTEMPX_H
	movf	SYSLONGDIVMULTX_U,W
	movwf	SYSLONGTEMPX_U
	movf	SYSLONGDIVMULTX_E,W
	movwf	SYSLONGTEMPX_E
	return

;********************************************************************************

SysStringTables
	movf	SysStringA_H,W
	movwf	PCLATH
	movf	SysStringA,W
	incf	SysStringA,F
	btfsc	STATUS,Z
	incf	SysStringA_H,F
	movwf	PCL

StringTable5
	retlw	39
	retlw	73	;I
	retlw	68	;D
	retlw	32	; 
	retlw	78	;N
	retlw	85	;U
	retlw	71	;G
	retlw	71	;G
	retlw	69	;E
	retlw	84	;T
	retlw	45	;-
	retlw	82	;R
	retlw	69	;E
	retlw	68	;D
	retlw	66	;B
	retlw	79	;O
	retlw	65	;A
	retlw	82	;R
	retlw	68	;D
	retlw	32	; 
	retlw	80	;P
	retlw	73	;I
	retlw	67	;C
	retlw	49	;1
	retlw	54	;6
	retlw	70	;F
	retlw	49	;1
	retlw	56	;8
	retlw	52	;4
	retlw	50	;2
	retlw	52	;4
	retlw	32	; 
	retlw	70	;F
	retlw	87	;W
	retlw	61	; (equals)
	retlw	48	;0
	retlw	46	;.
	retlw	49	;1
	retlw	46	;.
	retlw	49	;1


StringTable6
	retlw	12
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	84	;T
	retlw	85	;U
	retlw	83	;S
	retlw	32	; 
	retlw	82	;R
	retlw	69	;E
	retlw	65	;A
	retlw	68	;D
	retlw	89	;Y


StringTable7
	retlw	20
	retlw	79	;O
	retlw	75	;K
	retlw	32	; 
	retlw	83	;S
	retlw	84	;T
	retlw	79	;O
	retlw	80	;P
	retlw	32	; 
	retlw	76	;L
	retlw	79	;O
	retlw	67	;C
	retlw	65	;A
	retlw	76	;L
	retlw	95	;_
	retlw	66	;B
	retlw	85	;U
	retlw	84	;T
	retlw	84	;T
	retlw	79	;O
	retlw	78	;N


StringTable8
	retlw	21
	retlw	79	;O
	retlw	75	;K
	retlw	32	; 
	retlw	83	;S
	retlw	84	;T
	retlw	65	;A
	retlw	82	;R
	retlw	84	;T
	retlw	32	; 
	retlw	76	;L
	retlw	79	;O
	retlw	67	;C
	retlw	65	;A
	retlw	76	;L
	retlw	95	;_
	retlw	66	;B
	retlw	85	;U
	retlw	84	;T
	retlw	84	;T
	retlw	79	;O
	retlw	78	;N


StringTable9
	retlw	12
	retlw	68	;D
	retlw	65	;A
	retlw	84	;T
	retlw	65	;A
	retlw	32	; 
	retlw	83	;S
	retlw	65	;A
	retlw	77	;M
	retlw	80	;P
	retlw	76	;L
	retlw	69	;E
	retlw	32	; 


StringTable10
	retlw	5
	retlw	32	; 
	retlw	65	;A
	retlw	68	;D
	retlw	67	;C
	retlw	32	; 


;********************************************************************************

;Program_memory_page: 1
	ORG	2048

 END
