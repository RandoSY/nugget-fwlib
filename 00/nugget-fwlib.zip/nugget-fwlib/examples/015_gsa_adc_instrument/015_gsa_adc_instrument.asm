;Program compiled by GCBASIC (2025.01.10 (Windows 32 bit) : Build 1450) for Microchip MPASM/MPLAB-X Assembler using FreeBASIC 1.09.0/2026-05-03 CRC247
;Need help? 
;  Please donate to help support the operational costs of the project.  Donate via https://gcbasic.com/donate/
;  
;  See the GCBASIC forums at http://sourceforge.net/projects/gcbasic/forums,
;  Check the documentation and Help at http://gcbasic.sourceforge.net/help/,
;or, email us:
;   evanvennn at users dot sourceforge dot net
;********************************************************************************
;   Installation Dir : C:\Users\rasyoung\Desktop\DIY Tech For Experiments\Nugget\Pursuing the Nugget\nugget_frequency_meter_source\artifacts\toolchain-src\GCBASIC
;   Source file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\015_gsa_adc_instrument\015_gsa_adc_instrument.gcb
;   Setting file     : 
;   Preserve mode    : 0
;   Assembler        : 
;   Programmer       : 
;   Output file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\015_gsa_adc_instrument\015_gsa_adc_instrument.asm
;   Float Capability : 
;********************************************************************************

;Set up the assembler options (Chip type, clock source, other bits and pieces)
 LIST p=16F18424, r=DEC
 TITLE       "C:\Users\rasyoung\Desktop\nugget-fwlib\examples\015_gsa_adc_instrument\015_gsa_adc_instrument.gcb"
 SUBTITLE    "05-24-2026 16:58:00"
#include <P16F18424.inc>
 __CONFIG _CONFIG1, _FCMEN_ON & _CLKOUTEN_OFF & _RSTOSC_HFINT32 & _FEXTOSC_OFF
 __CONFIG _CONFIG2, _MCLRE_ON
 __CONFIG _CONFIG3, _WDTE_OFF
 __CONFIG _CONFIG4, _LVP_ON & _WRTSAF_OFF & _WRTD_OFF & _WRTB_OFF
 __CONFIG _CONFIG5, _CP_OFF

;********************************************************************************

;Set aside memory locations for variables
;  Shared/Access RAM = (SA)
ADREADPORT                       EQU      32          ; 0x20
ANSELB                           EQU      33          ; 0x21
COMPORT                          EQU      34          ; 0x22
DELAYTEMP                        EQU     112          ; 0x70 (SA)
DELAYTEMP2                       EQU     113          ; 0x71 (SA)
HSERPRINTCRLFCOUNT               EQU      35          ; 0x23
PRINTLEN                         EQU      36          ; 0x24
RB_ADC_READAVERAGE_AN2           EQU      37          ; 0x25
RB_ADC_READAVERAGE_AN2_H         EQU      38          ; 0x26
RB_I                             EQU      39          ; 0x27
RB_LINE                          EQU    8655          ; 0x21CF
RB_LINECOUNT                     EQU      40          ; 0x28
RB_SAMPLES                       EQU      41          ; 0x29
RB_TOTAL                         EQU      42          ; 0x2A
RB_TOTAL_E                       EQU      45          ; 0x2D
RB_TOTAL_H                       EQU      43          ; 0x2B
RB_TOTAL_U                       EQU      44          ; 0x2C
RB_VALUE                         EQU      46          ; 0x2E
RB_VALUE_E                       EQU      49          ; 0x31
RB_VALUE_H                       EQU      47          ; 0x2F
RB_VALUE_U                       EQU      48          ; 0x30
READAD                           EQU      50          ; 0x32
SERDATA                          EQU      51          ; 0x33
SERPRINTVAL                      EQU      52          ; 0x34
SERPRINTVAL_E                    EQU      55          ; 0x37
SERPRINTVAL_H                    EQU      53          ; 0x35
SERPRINTVAL_U                    EQU      54          ; 0x36
STRINGPOINTER                    EQU      56          ; 0x38
SYSBITVAR1                       EQU      57          ; 0x39
SYSBYTETEMPX                     EQU     112          ; 0x70 (SA)
SYSCALCTEMPA                     EQU     117          ; 0x75 (SA)
SYSCALCTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSCALCTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSCALCTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSDIVLOOP                       EQU     116          ; 0x74 (SA)
SYSLONGDIVMULTA                  EQU      58          ; 0x3A
SYSLONGDIVMULTA_E                EQU      61          ; 0x3D
SYSLONGDIVMULTA_H                EQU      59          ; 0x3B
SYSLONGDIVMULTA_U                EQU      60          ; 0x3C
SYSLONGDIVMULTB                  EQU      62          ; 0x3E
SYSLONGDIVMULTB_E                EQU      65          ; 0x41
SYSLONGDIVMULTB_H                EQU      63          ; 0x3F
SYSLONGDIVMULTB_U                EQU      64          ; 0x40
SYSLONGDIVMULTX                  EQU      66          ; 0x42
SYSLONGDIVMULTX_E                EQU      69          ; 0x45
SYSLONGDIVMULTX_H                EQU      67          ; 0x43
SYSLONGDIVMULTX_U                EQU      68          ; 0x44
SYSLONGTEMPA                     EQU     117          ; 0x75 (SA)
SYSLONGTEMPA_E                   EQU     120          ; 0x78 (SA)
SYSLONGTEMPA_H                   EQU     118          ; 0x76 (SA)
SYSLONGTEMPA_U                   EQU     119          ; 0x77 (SA)
SYSLONGTEMPB                     EQU     121          ; 0x79 (SA)
SYSLONGTEMPB_E                   EQU     124          ; 0x7C (SA)
SYSLONGTEMPB_H                   EQU     122          ; 0x7A (SA)
SYSLONGTEMPB_U                   EQU     123          ; 0x7B (SA)
SYSLONGTEMPX                     EQU     112          ; 0x70 (SA)
SYSLONGTEMPX_E                   EQU     115          ; 0x73 (SA)
SYSLONGTEMPX_H                   EQU     113          ; 0x71 (SA)
SYSLONGTEMPX_U                   EQU     114          ; 0x72 (SA)
SYSPRINTBUFFER                   EQU    8644          ; 0x21C4
SYSPRINTBUFFLEN                  EQU      70          ; 0x46
SYSPRINTDATAHANDLER              EQU      71          ; 0x47
SYSPRINTDATAHANDLER_H            EQU      72          ; 0x48
SYSPRINTTEMP                     EQU      73          ; 0x49
SYSRB_LABELHANDLER               EQU      74          ; 0x4A
SYSRB_LABELHANDLER_H             EQU      75          ; 0x4B
SYSREPEATTEMP1                   EQU      76          ; 0x4C
SYSSTRINGA                       EQU     119          ; 0x77 (SA)
SYSSTRINGA_H                     EQU     120          ; 0x78 (SA)
SYSSTRINGLENGTH                  EQU     118          ; 0x76 (SA)
SYSTEMP1                         EQU      77          ; 0x4D
SYSTEMP1_E                       EQU      80          ; 0x50
SYSTEMP1_H                       EQU      78          ; 0x4E
SYSTEMP1_U                       EQU      79          ; 0x4F
SYSWAITTEMP10US                  EQU     117          ; 0x75 (SA)
SYSWAITTEMPMS                    EQU     114          ; 0x72 (SA)
SYSWAITTEMPMS_H                  EQU     115          ; 0x73 (SA)
VALUE                            EQU      81          ; 0x51
VALUE_H                          EQU      82          ; 0x52

;********************************************************************************

;Alias variables
AFSR0 EQU 4
AFSR0_H EQU 5
SYSREADADBYTE EQU 50

;********************************************************************************

;Vectors
	ORG	0
	pagesel	BASPROGRAMSTART
	goto	BASPROGRAMSTART
	ORG	4
	retfie

;********************************************************************************

;Program_memory_page: 0
	ORG	5
BASPROGRAMSTART
;Call initialisation routines
	call	INITSYS
	call	INITUSART

;Start_of_the_main_program
	call	RB_BOARD_INIT
	call	RB_LED_STATUS_INIT
	call	RB_ADC_INIT
	call	RB_GSA_INIT
	call	RB_GSA_SENDID
SysDoLoop_S1
	movlw	8
	movwf	RB_SAMPLES
	call	FN_RB_ADC_READAVERAGE_AN2
	movf	RB_ADC_READAVERAGE_AN2,W
	movwf	VALUE
	movf	RB_ADC_READAVERAGE_AN2_H,W
	movwf	VALUE_H
	movlw	low StringTable2
	movwf	SysRB_LABELHandler
	movlw	(high StringTable2) | 128
	movwf	SysRB_LABELHandler_H
	movf	VALUE,W
	movwf	RB_VALUE
	movf	VALUE_H,W
	movwf	RB_VALUE_H
	clrf	RB_VALUE_U
	clrf	RB_VALUE_E
	call	RB_GSA_SENDDATAINT
	call	RB_LED_STATUS_TOGGLE
	movlw	232
	movwf	SysWaitTempMS
	movlw	3
	movwf	SysWaitTempMS_H
	call	Delay_MS
	goto	SysDoLoop_S1
SysDoLoop_E1
BASPROGRAMEND
	sleep
	goto	BASPROGRAMEND

;********************************************************************************

Delay_10US
D10US_START
	movlw	25
	movwf	DELAYTEMP
DelayUS0
	decfsz	DELAYTEMP,F
	goto	DelayUS0
	nop
	decfsz	SysWaitTemp10US, F
	goto	D10US_START
	return

;********************************************************************************

Delay_MS
	incf	SysWaitTempMS_H, F
DMS_START
	movlw	14
	movwf	DELAYTEMP2
DMS_OUTER
	movlw	189
	movwf	DELAYTEMP
DMS_INNER
	decfsz	DELAYTEMP, F
	goto	DMS_INNER
	decfsz	DELAYTEMP2, F
	goto	DMS_OUTER
	decfsz	SysWaitTempMS, F
	goto	DMS_START
	decfsz	SysWaitTempMS_H, F
	goto	DMS_START
	return

;********************************************************************************

HSERPRINT430
	movf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movf	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	PRINTLEN
	movf	PRINTLEN,F
	btfsc	STATUS, Z
	goto	ENDIF8
	clrf	SYSPRINTTEMP
	movlw	1
	subwf	PRINTLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd2
SysForLoop2
	incf	SYSPRINTTEMP,F
	movf	SYSPRINTTEMP,W
	addwf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movlw	0
	addwfc	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	SERDATA
	call	HSERSEND418
	movf	PRINTLEN,W
	subwf	SYSPRINTTEMP,W
	btfss	STATUS, C
	goto	SysForLoop2
SysForLoopEnd2
ENDIF8
	return

;********************************************************************************

HSERPRINT435
	clrf	SYSPRINTBUFFLEN
SysDoLoop_S2
	incf	SYSPRINTBUFFLEN,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTBUFFLEN,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movf	SERPRINTVAL,W
	movwf	SysLONGTempA
	movf	SERPRINTVAL_H,W
	movwf	SysLONGTempA_H
	movf	SERPRINTVAL_U,W
	movwf	SysLONGTempA_U
	movf	SERPRINTVAL_E,W
	movwf	SysLONGTempA_E
	movlw	10
	movwf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSDIVSUB32
	movf	SysLONGTempX,W
	movwf	INDF0
	movf	SYSCALCTEMPA,W
	movwf	SERPRINTVAL
	movf	SYSCALCTEMPA_H,W
	movwf	SERPRINTVAL_H
	movf	SYSCALCTEMPA_U,W
	movwf	SERPRINTVAL_U
	movf	SYSCALCTEMPA_E,W
	movwf	SERPRINTVAL_E
	movf	serprintval,W
	movwf	SysLONGTempA
	movf	serprintval_H,W
	movwf	SysLONGTempA_H
	movf	serprintval_U,W
	movwf	SysLONGTempA_U
	movf	serprintval_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	comf	SysByteTempX,F
	btfsc	SysByteTempX,0
	goto	SysDoLoop_S2
SysDoLoop_E2
	incf	SYSPRINTBUFFLEN,W
	movwf	SYSPRINTTEMP
	movlw	1
	subwf	SYSPRINTBUFFLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd3
SysForLoop3
	decf	SYSPRINTTEMP,F
	movlw	low(SYSPRINTBUFFER)
	addwf	SYSPRINTTEMP,W
	movwf	AFSR0
	clrf	SysTemp1
	movlw	high(SYSPRINTBUFFER)
	addwfc	SysTemp1,W
	movwf	AFSR0_H
	movlw	48
	addwf	INDF0,W
	movwf	SERDATA
	call	HSERSEND418
	movf	SYSPRINTTEMP,W
	sublw	1
	btfss	STATUS, C
	goto	SysForLoop3
SysForLoopEnd3
	return

;********************************************************************************

HSERPRINTCRLF
	movf	HSERPRINTCRLFCOUNT,W
	movwf	SysRepeatTemp1
	btfsc	STATUS,Z
	goto	SysRepeatLoopEnd1
SysRepeatLoop1
	movlw	13
	movwf	SERDATA
	call	HSERSEND418
	movlw	10
	movwf	SERDATA
	call	HSERSEND418
	decfsz	SysRepeatTemp1,F
	goto	SysRepeatLoop1
SysRepeatLoopEnd1
	return

;********************************************************************************

HSERSEND418
HSERSENDUSART1HANDLER
	movf	SERDATA,W
	banksel	TXREG
	movwf	TXREG
	movlw	1
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	banksel	STATUS
	goto	Delay_MS

;********************************************************************************

INITSYS
;Default settings for microcontrollers with _OSCCON1_
	movlw	96
	banksel	OSCCON1
	movwf	OSCCON1
	clrf	OSCCON3
	clrf	OSCEN
	clrf	OSCTUNE
;The MCU is a chip family ChipFamily
;OSCCON type is 102
	movlw	6
	movwf	OSCFRQ
;_Complete_the_chip_setup_of_BSR_ADCs_ANSEL_and_other_key_setup_registers_or_register_bits
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	CM2CON0
	bcf	CM2CON0,C2EN
	bcf	CM1CON0,C1EN
	banksel	PORTA
	clrf	PORTA
	clrf	PORTC
	return

;********************************************************************************

INITUSART
	movlw	3
	banksel	SP1BRGH
	movwf	SP1BRGH
	movlw	64
	movwf	SP1BRGL
	movlw	64
	movwf	SPBRG
	bsf	BAUD1CON,BRG16
	bsf	TX1STA,BRGH
	bcf	TX1STA,SYNC_TX1STA
	bsf	TX1STA,TXEN
	bsf	RC1STA,SPEN
	bsf	RC1STA,CREN
	bsf	RC1STA,CREN
	banksel	STATUS
	return

;********************************************************************************

RB_ADC_INIT
	bsf	TRISA,2
	banksel	ANSELA
	bsf	ANSELA,2
	banksel	STATUS
	return

;********************************************************************************

FN_RB_ADC_READAVERAGE_AN2
	clrf	RB_TOTAL
	clrf	RB_TOTAL_H
	clrf	RB_TOTAL_U
	clrf	RB_TOTAL_E
	clrf	RB_I
	movlw	1
	subwf	RB_SAMPLES,W
	btfss	STATUS, C
	goto	SysForLoopEnd1
SysForLoop1
	incf	RB_I,F
	movlw	2
	movwf	ADREADPORT
	call	FN_READAD86
	movf	SYSREADADBYTE,W
	addwf	RB_TOTAL,F
	movlw	0
	addwfc	RB_TOTAL_H,F
	movlw	0
	addwfc	RB_TOTAL_U,F
	movlw	0
	addwfc	RB_TOTAL_E,F
	movlw	2
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	movf	RB_SAMPLES,W
	subwf	RB_I,W
	btfss	STATUS, C
	goto	SysForLoop1
SysForLoopEnd1
	movf	RB_TOTAL,W
	movwf	SysLONGTempA
	movf	RB_TOTAL_H,W
	movwf	SysLONGTempA_H
	movf	RB_TOTAL_U,W
	movwf	SysLONGTempA_U
	movf	RB_TOTAL_E,W
	movwf	SysLONGTempA_E
	movf	RB_SAMPLES,W
	movwf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSDIVSUB32
	movf	SysLONGTempA,W
	movwf	RB_ADC_READAVERAGE_AN2
	movf	SysLONGTempA_H,W
	movwf	RB_ADC_READAVERAGE_AN2_H
	return

;********************************************************************************

RB_BOARD_INIT
	goto	RB_CORE_INIT

;********************************************************************************

RB_CORE_ALLDIGITAL
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	STATUS
	return

;********************************************************************************

RB_CORE_CLEARLATCHES
	clrf	LATA
	clrf	LATC
	return

;********************************************************************************

RB_CORE_INIT
	call	RB_CORE_ALLDIGITAL
	goto	RB_CORE_CLEARLATCHES

;********************************************************************************

RB_GSA_INIT
	call	RB_LINEBUF_INIT
	bcf	SYSBITVAR1,6
	bcf	SYSBITVAR1,7
	return

;********************************************************************************

RB_GSA_SENDDATAINT
	movlw	low StringTable36
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable36) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	SysRB_LABELHandler,W
	movwf	SysPRINTDATAHandler
	movf	SysRB_LABELHandler_H,W
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	low StringTable28
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable28) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	RB_VALUE,W
	movwf	SERPRINTVAL
	movf	RB_VALUE_H,W
	movwf	SERPRINTVAL_H
	movf	RB_VALUE_U,W
	movwf	SERPRINTVAL_U
	movf	RB_VALUE_E,W
	movwf	SERPRINTVAL_E
	movlw	1
	movwf	COMPORT
	call	HSERPRINT435
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_GSA_SENDID
	movlw	low StringTable35
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable35) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	goto	HSERPRINTCRLF

;********************************************************************************

RB_LED_STATUS_INIT
	bcf	TRISC,0
	banksel	ANSELC
	bcf	ANSELC,0
	banksel	LATC
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_TOGGLE
	clrf	SysTemp1
	btfsc	LATC,0
	incf	SysTemp1,F
	comf	SysTemp1,F
	bcf	LATC,0
	btfsc	SysTemp1,0
	bsf	LATC,0
	return

;********************************************************************************

RB_LINEBUF_INIT
	movlw	low RB_LINE
	movwf	FSR1L
	movlw	high RB_LINE
	movwf	FSR1H
	movlw	low StringTable30
	movwf	SysStringA
	movlw	(high StringTable30) & 127
	movwf	SysStringA_H
	call	SYSREADSTRING
	bcf	SYSBITVAR1,4
	clrf	RB_LINECOUNT
	bcf	SYSBITVAR1,5
	return

;********************************************************************************

FN_READAD86
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	banksel	ADREADPORT
	movf	ADREADPORT,W
	banksel	ADPCH
	movwf	ADPCH
SysSelect1Case1
	banksel	ADREADPORT
	movf	ADREADPORT,F
	btfss	STATUS, Z
	goto	SysSelect1Case2
	banksel	ANSELA
	bsf	ANSELA,0
	goto	SysSelectEnd1
SysSelect1Case2
	decf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case3
	banksel	ANSELA
	bsf	ANSELA,1
	goto	SysSelectEnd1
SysSelect1Case3
	movlw	2
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case4
	banksel	ANSELA
	bsf	ANSELA,2
	goto	SysSelectEnd1
SysSelect1Case4
	movlw	3
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case5
	banksel	ANSELA
	bsf	ANSELA,3
	goto	SysSelectEnd1
SysSelect1Case5
	movlw	4
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case6
	banksel	ANSELA
	bsf	ANSELA,4
	goto	SysSelectEnd1
SysSelect1Case6
	movlw	5
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case7
	banksel	ANSELA
	bsf	ANSELA,5
	goto	SysSelectEnd1
SysSelect1Case7
	movlw	6
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case8
	banksel	ANSELA
	bsf	ANSELA,6
	goto	SysSelectEnd1
SysSelect1Case8
	movlw	7
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case9
	banksel	ANSELA
	bsf	ANSELA,7
	goto	SysSelectEnd1
SysSelect1Case9
	movlw	8
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case10
	bsf	ANSELB,0
	goto	SysSelectEnd1
SysSelect1Case10
	movlw	9
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case11
	bsf	ANSELB,1
	goto	SysSelectEnd1
SysSelect1Case11
	movlw	10
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case12
	bsf	ANSELB,2
	goto	SysSelectEnd1
SysSelect1Case12
	movlw	11
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case13
	bsf	ANSELB,3
	goto	SysSelectEnd1
SysSelect1Case13
	movlw	12
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case14
	bsf	ANSELB,4
	goto	SysSelectEnd1
SysSelect1Case14
	movlw	13
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case15
	bsf	ANSELB,5
	goto	SysSelectEnd1
SysSelect1Case15
	movlw	14
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case16
	bsf	ANSELB,6
	goto	SysSelectEnd1
SysSelect1Case16
	movlw	15
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case17
	bsf	ANSELB,7
	goto	SysSelectEnd1
SysSelect1Case17
	movlw	16
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case18
	banksel	ANSELC
	bsf	ANSELC,0
	goto	SysSelectEnd1
SysSelect1Case18
	movlw	17
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case19
	banksel	ANSELC
	bsf	ANSELC,1
	goto	SysSelectEnd1
SysSelect1Case19
	movlw	18
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case20
	banksel	ANSELC
	bsf	ANSELC,2
	goto	SysSelectEnd1
SysSelect1Case20
	movlw	19
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case21
	banksel	ANSELC
	bsf	ANSELC,3
	goto	SysSelectEnd1
SysSelect1Case21
	movlw	20
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case22
	banksel	ANSELC
	bsf	ANSELC,4
	goto	SysSelectEnd1
SysSelect1Case22
	movlw	21
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case23
	banksel	ANSELC
	bsf	ANSELC,5
	goto	SysSelectEnd1
SysSelect1Case23
	movlw	22
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelect1Case24
	banksel	ANSELC
	bsf	ANSELC,6
	goto	SysSelectEnd1
SysSelect1Case24
	movlw	23
	subwf	ADREADPORT,W
	btfss	STATUS, Z
	goto	SysSelectEnd1
	banksel	ANSELC
	bsf	ANSELC,7
SysSelectEnd1
	banksel	ADCON0
	bcf	ADCON0,ADCS
	movlw	1
	movwf	ADCLK
	bcf	ADCON0,ADCS
	movlw	15
	movwf	ADCLK
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADFM0
	banksel	ADREADPORT
	movf	ADREADPORT,W
	banksel	ADPCH
	movwf	ADPCH
	banksel	ADCON0
	bsf	ADCON0,ADON
	movlw	2
	movwf	SysWaitTemp10US
	banksel	STATUS
	call	Delay_10US
	banksel	ADCON0
	bsf	ADCON0,GO_NOT_DONE
	nop
SysWaitLoop1
	btfsc	ADCON0,GO_NOT_DONE
	goto	SysWaitLoop1
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	ADRESH
	movf	ADRESH,W
	banksel	READAD
	movwf	READAD
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	banksel	STATUS
	return

;********************************************************************************

SYSCOMPEQUAL32
	clrf	SYSBYTETEMPX
	movf	SYSLONGTEMPA, W
	subwf	SYSLONGTEMPB, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_H, W
	subwf	SYSLONGTEMPB_H, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_U, W
	subwf	SYSLONGTEMPB_U, W
	btfss	STATUS, Z
	return
	movf	SYSLONGTEMPA_E, W
	subwf	SYSLONGTEMPB_E, W
	btfss	STATUS, Z
	return
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSDIVSUB32
	movf	SYSLONGTEMPA,W
	movwf	SYSLONGDIVMULTA
	movf	SYSLONGTEMPA_H,W
	movwf	SYSLONGDIVMULTA_H
	movf	SYSLONGTEMPA_U,W
	movwf	SYSLONGDIVMULTA_U
	movf	SYSLONGTEMPA_E,W
	movwf	SYSLONGDIVMULTA_E
	movf	SYSLONGTEMPB,W
	movwf	SYSLONGDIVMULTB
	movf	SYSLONGTEMPB_H,W
	movwf	SYSLONGDIVMULTB_H
	movf	SYSLONGTEMPB_U,W
	movwf	SYSLONGDIVMULTB_U
	movf	SYSLONGTEMPB_E,W
	movwf	SYSLONGDIVMULTB_E
	clrf	SYSLONGDIVMULTX
	clrf	SYSLONGDIVMULTX_H
	clrf	SYSLONGDIVMULTX_U
	clrf	SYSLONGDIVMULTX_E
	movf	SYSLONGDIVMULTB,W
	movwf	SysLONGTempA
	movf	SYSLONGDIVMULTB_H,W
	movwf	SysLONGTempA_H
	movf	SYSLONGDIVMULTB_U,W
	movwf	SysLONGTempA_U
	movf	SYSLONGDIVMULTB_E,W
	movwf	SysLONGTempA_E
	clrf	SysLONGTempB
	clrf	SysLONGTempB_H
	clrf	SysLONGTempB_U
	clrf	SysLONGTempB_E
	call	SYSCOMPEQUAL32
	btfss	SysByteTempX,0
	goto	ENDIF6
	clrf	SYSLONGTEMPA
	clrf	SYSLONGTEMPA_H
	clrf	SYSLONGTEMPA_U
	clrf	SYSLONGTEMPA_E
	return
ENDIF6
	movlw	32
	movwf	SYSDIVLOOP
SYSDIV32START
	bcf	STATUS,C
	rlf	SYSLONGDIVMULTA,F
	rlf	SYSLONGDIVMULTA_H,F
	rlf	SYSLONGDIVMULTA_U,F
	rlf	SYSLONGDIVMULTA_E,F
	rlf	SYSLONGDIVMULTX,F
	rlf	SYSLONGDIVMULTX_H,F
	rlf	SYSLONGDIVMULTX_U,F
	rlf	SYSLONGDIVMULTX_E,F
	movf	SYSLONGDIVMULTB,W
	subwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	subwfb	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	subwfb	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	subwfb	SYSLONGDIVMULTX_E,F
	bsf	SYSLONGDIVMULTA,0
	btfsc	STATUS,C
	goto	ENDIF7
	bcf	SYSLONGDIVMULTA,0
	movf	SYSLONGDIVMULTB,W
	addwf	SYSLONGDIVMULTX,F
	movf	SYSLONGDIVMULTB_H,W
	addwfc	SYSLONGDIVMULTX_H,F
	movf	SYSLONGDIVMULTB_U,W
	addwfc	SYSLONGDIVMULTX_U,F
	movf	SYSLONGDIVMULTB_E,W
	addwfc	SYSLONGDIVMULTX_E,F
ENDIF7
	decfsz	SYSDIVLOOP, F
	goto	SYSDIV32START
	movf	SYSLONGDIVMULTA,W
	movwf	SYSLONGTEMPA
	movf	SYSLONGDIVMULTA_H,W
	movwf	SYSLONGTEMPA_H
	movf	SYSLONGDIVMULTA_U,W
	movwf	SYSLONGTEMPA_U
	movf	SYSLONGDIVMULTA_E,W
	movwf	SYSLONGTEMPA_E
	movf	SYSLONGDIVMULTX,W
	movwf	SYSLONGTEMPX
	movf	SYSLONGDIVMULTX_H,W
	movwf	SYSLONGTEMPX_H
	movf	SYSLONGDIVMULTX_U,W
	movwf	SYSLONGTEMPX_U
	movf	SYSLONGDIVMULTX_E,W
	movwf	SYSLONGTEMPX_E
	return

;********************************************************************************

SYSREADSTRING
	call	SYSSTRINGTABLES
	movwf	SYSCALCTEMPA
	movwf	INDF1
	goto	SYSSTRINGREADCHECK
SYSREADSTRINGPART
	call	SYSSTRINGTABLES
	movwf	SYSCALCTEMPA
	addwf	SYSSTRINGLENGTH,F
SYSSTRINGREADCHECK
	movf	SYSCALCTEMPA,F
	btfsc	STATUS,Z
	return
SYSSTRINGREAD
	call	SYSSTRINGTABLES
	addfsr	1,1
	movwf	INDF1
	decfsz	SYSCALCTEMPA, F
	goto	SYSSTRINGREAD
	return

;********************************************************************************

SysStringTables
	movf	SysStringA_H,W
	movwf	PCLATH
	movf	SysStringA,W
	incf	SysStringA,F
	btfsc	STATUS,Z
	incf	SysStringA_H,F
	movwf	PCL

StringTable2
	retlw	3
	retlw	65	;A
	retlw	68	;D
	retlw	67	;C


StringTable28
	retlw	1
	retlw	32	; 


StringTable30
	retlw	0


StringTable35
	retlw	39
	retlw	73	;I
	retlw	68	;D
	retlw	32	; 
	retlw	78	;N
	retlw	85	;U
	retlw	71	;G
	retlw	71	;G
	retlw	69	;E
	retlw	84	;T
	retlw	45	;-
	retlw	82	;R
	retlw	69	;E
	retlw	68	;D
	retlw	66	;B
	retlw	79	;O
	retlw	65	;A
	retlw	82	;R
	retlw	68	;D
	retlw	32	; 
	retlw	80	;P
	retlw	73	;I
	retlw	67	;C
	retlw	49	;1
	retlw	54	;6
	retlw	70	;F
	retlw	49	;1
	retlw	56	;8
	retlw	52	;4
	retlw	50	;2
	retlw	52	;4
	retlw	32	; 
	retlw	70	;F
	retlw	87	;W
	retlw	61	; (equals)
	retlw	48	;0
	retlw	46	;.
	retlw	49	;1
	retlw	46	;.
	retlw	48	;0


StringTable36
	retlw	5
	retlw	68	;D
	retlw	65	;A
	retlw	84	;T
	retlw	65	;A
	retlw	32	; 


;********************************************************************************

;Program_memory_page: 1
	ORG	2048

 END
