;Program compiled by GCBASIC (2025.01.10 (Windows 32 bit) : Build 1450) for Microchip MPASM/MPLAB-X Assembler using FreeBASIC 1.09.0/2026-05-03 CRC247
;Need help? 
;  Please donate to help support the operational costs of the project.  Donate via https://gcbasic.com/donate/
;  
;  See the GCBASIC forums at http://sourceforge.net/projects/gcbasic/forums,
;  Check the documentation and Help at http://gcbasic.sourceforge.net/help/,
;or, email us:
;   evanvennn at users dot sourceforge dot net
;********************************************************************************
;   Installation Dir : C:\Users\rasyoung\Desktop\DIY Tech For Experiments\Nugget\Pursuing the Nugget\nugget_frequency_meter_source\artifacts\toolchain-src\GCBASIC
;   Source file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\017_button_modes\017_button_modes.gcb
;   Setting file     : 
;   Preserve mode    : 0
;   Assembler        : 
;   Programmer       : 
;   Output file      : C:\Users\rasyoung\Desktop\nugget-fwlib\examples\017_button_modes\017_button_modes.asm
;   Float Capability : 
;********************************************************************************

;Set up the assembler options (Chip type, clock source, other bits and pieces)
 LIST p=16F18424, r=DEC
 TITLE       "C:\Users\rasyoung\Desktop\nugget-fwlib\examples\017_button_modes\017_button_modes.gcb"
 SUBTITLE    "05-24-2026 16:58:09"
#include <P16F18424.inc>
 __CONFIG _CONFIG1, _FCMEN_ON & _CLKOUTEN_OFF & _RSTOSC_HFINT32 & _FEXTOSC_OFF
 __CONFIG _CONFIG2, _MCLRE_ON
 __CONFIG _CONFIG3, _WDTE_OFF
 __CONFIG _CONFIG4, _LVP_ON & _WRTSAF_OFF & _WRTD_OFF & _WRTB_OFF
 __CONFIG _CONFIG5, _CP_OFF

;********************************************************************************

;Set aside memory locations for variables
;  Shared/Access RAM = (SA)
COMPORT                          EQU      32          ; 0x20
DELAYTEMP                        EQU     112          ; 0x70 (SA)
DELAYTEMP2                       EQU     113          ; 0x71 (SA)
HSERPRINTCRLFCOUNT               EQU      33          ; 0x21
MODE                             EQU      34          ; 0x22
OUTVALUETEMP                     EQU      35          ; 0x23
PRINTLEN                         EQU      36          ; 0x24
SERDATA                          EQU      37          ; 0x25
SERPRINTVAL                      EQU      38          ; 0x26
STRINGPOINTER                    EQU      39          ; 0x27
SYSBITVAR0                       EQU      40          ; 0x28
SYSBYTETEMPA                     EQU     117          ; 0x75 (SA)
SYSBYTETEMPB                     EQU     121          ; 0x79 (SA)
SYSBYTETEMPX                     EQU     112          ; 0x70 (SA)
SYSCALCTEMPX                     EQU     112          ; 0x70 (SA)
SYSDIVLOOP                       EQU     116          ; 0x74 (SA)
SYSPRINTDATAHANDLER              EQU      41          ; 0x29
SYSPRINTDATAHANDLER_H            EQU      42          ; 0x2A
SYSPRINTTEMP                     EQU      43          ; 0x2B
SYSREPEATTEMP1                   EQU      44          ; 0x2C
SYSSTRINGA                       EQU     119          ; 0x77 (SA)
SYSSTRINGA_H                     EQU     120          ; 0x78 (SA)
SYSTEMP1                         EQU      45          ; 0x2D
SYSTEMP2                         EQU      46          ; 0x2E
SYSWAITTEMPMS                    EQU     114          ; 0x72 (SA)
SYSWAITTEMPMS_H                  EQU     115          ; 0x73 (SA)

;********************************************************************************

;Alias variables
AFSR0 EQU 4
AFSR0_H EQU 5

;********************************************************************************

;Vectors
	ORG	0
	pagesel	BASPROGRAMSTART
	goto	BASPROGRAMSTART
	ORG	4
	retfie

;********************************************************************************

;Program_memory_page: 0
	ORG	5
BASPROGRAMSTART
;Call initialisation routines
	call	INITSYS
	call	INITUSART

;Start_of_the_main_program
	call	RB_BOARD_INIT
	call	RB_SW1_INITPULLUP
	call	RB_LED_STATUS_INIT
	clrf	MODE
SysDoLoop_S1
	call	FN_RB_SW1_PRESSEDEVENT
	btfss	SYSBITVAR0,5
	goto	ENDIF1
	incf	MODE,F
	movf	MODE,W
	sublw	3
	btfss	STATUS, C
	clrf	MODE
	movlw	low StringTable2
	movwf	SysPRINTDATAHandler
	movlw	(high StringTable2) | 128
	movwf	SysPRINTDATAHandler_H
	movlw	1
	movwf	COMPORT
	call	HSERPRINT430
	movf	MODE,W
	movwf	SERPRINTVAL
	movlw	1
	movwf	COMPORT
	call	HSERPRINT432
	movlw	1
	movwf	HSERPRINTCRLFCOUNT
	movlw	1
	movwf	COMPORT
	call	HSERPRINTCRLF
ENDIF1
SysSelect1Case1
	movf	MODE,F
	btfss	STATUS, Z
	goto	SysSelect1Case2
	call	RB_LED_STATUS_OFF
	goto	SysSelectEnd1
SysSelect1Case2
	decf	MODE,W
	btfss	STATUS, Z
	goto	SysSelect1Case3
	call	RB_LED_STATUS_ON
	goto	SysSelectEnd1
SysSelect1Case3
	movlw	2
	subwf	MODE,W
	btfss	STATUS, Z
	goto	SysSelect1Case4
	call	RB_LED_STATUS_TOGGLE
	movlw	250
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	goto	SysSelectEnd1
SysSelect1Case4
	movlw	3
	subwf	MODE,W
	btfss	STATUS, Z
	goto	SysSelectEnd1
	call	RB_LED_STATUS_TOGGLE
	movlw	75
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
SysSelectEnd1
	goto	SysDoLoop_S1
SysDoLoop_E1
BASPROGRAMEND
	sleep
	goto	BASPROGRAMEND

;********************************************************************************

Delay_MS
	incf	SysWaitTempMS_H, F
DMS_START
	movlw	14
	movwf	DELAYTEMP2
DMS_OUTER
	movlw	189
	movwf	DELAYTEMP
DMS_INNER
	decfsz	DELAYTEMP, F
	goto	DMS_INNER
	decfsz	DELAYTEMP2, F
	goto	DMS_OUTER
	decfsz	SysWaitTempMS, F
	goto	DMS_START
	decfsz	SysWaitTempMS_H, F
	goto	DMS_START
	return

;********************************************************************************

HSERPRINT430
	movf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movf	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	PRINTLEN
	movf	PRINTLEN,F
	btfsc	STATUS, Z
	goto	ENDIF10
	clrf	SYSPRINTTEMP
	movlw	1
	subwf	PRINTLEN,W
	btfss	STATUS, C
	goto	SysForLoopEnd1
SysForLoop1
	incf	SYSPRINTTEMP,F
	movf	SYSPRINTTEMP,W
	addwf	SysPRINTDATAHandler,W
	movwf	AFSR0
	movlw	0
	addwfc	SysPRINTDATAHandler_H,W
	movwf	AFSR0_H
	movf	INDF0,W
	movwf	SERDATA
	call	HSERSEND418
	movf	PRINTLEN,W
	subwf	SYSPRINTTEMP,W
	btfss	STATUS, C
	goto	SysForLoop1
SysForLoopEnd1
ENDIF10
	return

;********************************************************************************

HSERPRINT432
	clrf	OUTVALUETEMP
	movlw	100
	subwf	SERPRINTVAL,W
	btfss	STATUS, C
	goto	ENDIF13
	movf	SERPRINTVAL,W
	movwf	SysBYTETempA
	movlw	100
	movwf	SysBYTETempB
	call	SYSDIVSUB
	movf	SysBYTETempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND418
ENDIF13
	movf	OUTVALUETEMP,W
	movwf	SysBYTETempB
	clrf	SysBYTETempA
	call	SYSCOMPLESSTHAN
	movf	SysByteTempX,W
	movwf	SysTemp1
	movf	SERPRINTVAL,W
	movwf	SysBYTETempA
	movlw	10
	movwf	SysBYTETempB
	call	SYSCOMPLESSTHAN
	comf	SysByteTempX,F
	movf	SysTemp1,W
	iorwf	SysByteTempX,W
	movwf	SysTemp2
	btfss	SysTemp2,0
	goto	ENDIF14
	movf	SERPRINTVAL,W
	movwf	SysBYTETempA
	movlw	10
	movwf	SysBYTETempB
	call	SYSDIVSUB
	movf	SysBYTETempA,W
	movwf	OUTVALUETEMP
	movf	SYSCALCTEMPX,W
	movwf	SERPRINTVAL
	movlw	48
	addwf	OUTVALUETEMP,W
	movwf	SERDATA
	call	HSERSEND418
ENDIF14
	movlw	48
	addwf	SERPRINTVAL,W
	movwf	SERDATA
	goto	HSERSEND418

;********************************************************************************

HSERPRINTCRLF
	movf	HSERPRINTCRLFCOUNT,W
	movwf	SysRepeatTemp1
	btfsc	STATUS,Z
	goto	SysRepeatLoopEnd1
SysRepeatLoop1
	movlw	13
	movwf	SERDATA
	call	HSERSEND418
	movlw	10
	movwf	SERDATA
	call	HSERSEND418
	decfsz	SysRepeatTemp1,F
	goto	SysRepeatLoop1
SysRepeatLoopEnd1
	return

;********************************************************************************

HSERSEND418
HSERSENDUSART1HANDLER
	movf	SERDATA,W
	banksel	TXREG
	movwf	TXREG
	movlw	1
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	banksel	STATUS
	goto	Delay_MS

;********************************************************************************

INITSYS
;Default settings for microcontrollers with _OSCCON1_
	movlw	96
	banksel	OSCCON1
	movwf	OSCCON1
	clrf	OSCCON3
	clrf	OSCEN
	clrf	OSCTUNE
;The MCU is a chip family ChipFamily
;OSCCON type is 102
	movlw	6
	movwf	OSCFRQ
;_Complete_the_chip_setup_of_BSR_ADCs_ANSEL_and_other_key_setup_registers_or_register_bits
	banksel	ADCON0
	bcf	ADCON0,ADFM0
	bcf	ADCON0,ADON
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	CM2CON0
	bcf	CM2CON0,C2EN
	bcf	CM1CON0,C1EN
	banksel	PORTA
	clrf	PORTA
	clrf	PORTC
	return

;********************************************************************************

INITUSART
	movlw	3
	banksel	SP1BRGH
	movwf	SP1BRGH
	movlw	64
	movwf	SP1BRGL
	movlw	64
	movwf	SPBRG
	bsf	BAUD1CON,BRG16
	bsf	TX1STA,BRGH
	bcf	TX1STA,SYNC_TX1STA
	bsf	TX1STA,TXEN
	bsf	RC1STA,SPEN
	bsf	RC1STA,CREN
	bsf	RC1STA,CREN
	banksel	STATUS
	return

;********************************************************************************

RB_BOARD_INIT
	goto	RB_CORE_INIT

;********************************************************************************

RB_CORE_ALLDIGITAL
	banksel	ANSELA
	clrf	ANSELA
	clrf	ANSELC
	banksel	STATUS
	return

;********************************************************************************

RB_CORE_CLEARLATCHES
	clrf	LATA
	clrf	LATC
	return

;********************************************************************************

RB_CORE_INIT
	call	RB_CORE_ALLDIGITAL
	goto	RB_CORE_CLEARLATCHES

;********************************************************************************

RB_LED_STATUS_INIT
	bcf	TRISC,0
	banksel	ANSELC
	bcf	ANSELC,0
	banksel	LATC
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_OFF
	bcf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_ON
	bsf	LATC,0
	return

;********************************************************************************

RB_LED_STATUS_TOGGLE
	clrf	SysTemp1
	btfsc	LATC,0
	incf	SysTemp1,F
	comf	SysTemp1,F
	bcf	LATC,0
	btfsc	SysTemp1,0
	bsf	LATC,0
	return

;********************************************************************************

RB_SW1_INITPULLUP
	bsf	TRISA,0
	banksel	ANSELA
	bcf	ANSELA,0
	bsf	WPUA,0
	banksel	SYSBITVAR0
	bcf	SYSBITVAR0,0
	btfsc	PORTA,0
	bsf	SYSBITVAR0,0
	bcf	SYSBITVAR0,1
	return

;********************************************************************************

FN_RB_SW1_PRESSEDEVENT
	bcf	SYSBITVAR0,5
	btfss	SYSBITVAR0,0
	goto	ENDIF6
	btfsc	PORTA,0
	goto	ENDIF7
	movlw	20
	movwf	SysWaitTempMS
	clrf	SysWaitTempMS_H
	call	Delay_MS
	btfss	PORTA,0
	bsf	SYSBITVAR0,5
ENDIF7
ENDIF6
	bcf	SYSBITVAR0,0
	btfsc	PORTA,0
	bsf	SYSBITVAR0,0
	return

;********************************************************************************

SYSCOMPLESSTHAN
	clrf	SYSBYTETEMPX
	bsf	STATUS, C
	movf	SYSBYTETEMPB, W
	subwf	SYSBYTETEMPA, W
	btfss	STATUS, C
	comf	SYSBYTETEMPX,F
	return

;********************************************************************************

SYSDIVSUB
	movf	SYSBYTETEMPB, F
	btfsc	STATUS, Z
	return
	clrf	SYSBYTETEMPX
	movlw	8
	movwf	SYSDIVLOOP
SYSDIV8START
	bcf	STATUS, C
	rlf	SYSBYTETEMPA, F
	rlf	SYSBYTETEMPX, F
	movf	SYSBYTETEMPB, W
	subwf	SYSBYTETEMPX, F
	bsf	SYSBYTETEMPA, 0
	btfsc	STATUS, C
	goto	DIV8NOTNEG
	bcf	SYSBYTETEMPA, 0
	movf	SYSBYTETEMPB, W
	addwf	SYSBYTETEMPX, F
DIV8NOTNEG
	decfsz	SYSDIVLOOP, F
	goto	SYSDIV8START
	return

;********************************************************************************

SysStringTables
	movf	SysStringA_H,W
	movwf	PCLATH
	movf	SysStringA,W
	incf	SysStringA,F
	btfsc	STATUS,Z
	incf	SysStringA_H,F
	movwf	PCL

StringTable2
	retlw	5
	retlw	77	;M
	retlw	79	;O
	retlw	68	;D
	retlw	69	;E
	retlw	32	; 


;********************************************************************************

;Program_memory_page: 1
	ORG	2048

 END
